function LightGridViewportModel()
{
    

}