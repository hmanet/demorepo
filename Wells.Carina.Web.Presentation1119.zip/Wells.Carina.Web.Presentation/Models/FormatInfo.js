// function FormatInfo(editable, foreground, background, fontFamily, fontWeight, fontStyle, fontSize, visible, strikethrough, underline) {
//     this.Editable = editable;
//     this.Foreground = foreground;
//     this.Background = background;
//     this.FontFamily = fontFamily;
//     this.FontWeight = fontWeight;
//     this.FontStyle = fontStyle;
//     this.FontSize = fontSize;
//     this.Visible = visible;
//     this.Strikethrough = strikethrough;
//     this.Underline = underline;

// };
function FormatInfo(data) {
    this.Editable = data.Editable;
    this.Foreground = data.Foreground;
    this.Background = data.Background;
    this.FontFamily = data.Editable;
    this.FontWeight = data.FontWeight;
    this.FontStyle = data.FontStyle;
    this.FontSize = data.FontSize;
    this.Visible = data.Visible;
    this.Strikethrough = data.Strikethrough;
    this.Underline = data.Underline;

};