function LightGridCellRenderer(cell, column) {
    column.Top=cell.Top;
    column.Left=cell.Left;
    var cellObj = new LightGridCell(cell.Data, cell.FormatInfo ? cell.FormatInfo : column);
    elem = CreateCell(cellObj);
    elem.setAttribute("id", cell.ColumnIndex.toString() + cell.RowIndex.toString());
    return elem;
}