﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class LightGridCell
    {
        [JsonProperty(PropertyName = "data")]
        public object Data { get; set; }

        [JsonProperty(PropertyName = "rowIndex")]
        public int RowIndex { get; set; }

        [JsonProperty(PropertyName = "columnIndex")]
        public int ColumnIndex { get; set; }

        [JsonProperty(PropertyName = "formatInfo")]
        public FormatInfo FormatInfo { get; set; }
    }
}