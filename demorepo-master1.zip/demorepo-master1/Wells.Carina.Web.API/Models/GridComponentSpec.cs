﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class GridComponentSpec
    {
        [JsonProperty(PropertyName = "gridType")]
        public string GridType { get; set; }

        [JsonProperty(PropertyName = "gridRunTimeId")]
        public int GridRunTimeId { get; set; }

        [JsonProperty(PropertyName = "rowHeight")]
        public int RowHeight { get; set; }

        [JsonProperty(PropertyName = "totalRowCount")]
        public int TotalRowCount { get; set; }

        //[JsonProperty(PropertyName = "displayRowCount")]
        //public int DisplayRowCount { get; set; }
        [JsonProperty(PropertyName = "columnHeaderHeight")]
        public int ColumnHeaderHeight { get; set; }
    }
}