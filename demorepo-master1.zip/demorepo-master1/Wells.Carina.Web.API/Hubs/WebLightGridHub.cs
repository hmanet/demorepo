﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wells.Carina.Web.API.Models;


namespace Wells.Carina.Web.API.Hubs
{
    public class WebLightGridHub : CarinaHubBase
    {
        public WebLightGridHub():base()
        { }

        
        public void ExecuteCommand(RequestMessage request)
        {
            var snapshot = CarinaSnapShotBuilder.GetSnapShot(request.ViewPort);

            string gridRunTimeId = Context.QueryString["gridRuntimeId"];

            foreach (var connectionId in connections.GetConnections(gridRunTimeId))
            {
                Clients.Client(connectionId).recieveGridCommand(snapshot);
            }
        }


    }
    
}
