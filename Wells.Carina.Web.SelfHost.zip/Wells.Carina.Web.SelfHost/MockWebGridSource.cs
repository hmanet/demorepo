﻿using System;
using System.Collections.Generic;
using Microsoft.Owin.Hosting;
using Wells.Carina.Web.API;
using Wells.Carina.Web.API.Hubs;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Requests;
using Wells.Carina.Web.API.Models.Responses;
using Wells.Derivatives.Carina.Core.Threading;

namespace Wells.Carina.Web.SelfHost
{
    internal class MockWebGridSource : IWebLightGridSource
    {
        private IClient client;

        private BackgroundQueue<Action> queue = BackgroundQueue<Action>.Single(x => x());
        private Dictionary<int, WebGridRequest> requests = new Dictionary<int, WebGridRequest>();
        private string hostingAddress = "http://localhost:9000/";
        private int totalRowCount;
        private string gridId;
        public MockWebGridSource(int rows)
        {
           GridId = "12345";
           
           totalRowCount = rows;
           CarinaSnapShotBuilder.Initialize(rows);
           gridId = "12345";
           WebLightGridSources.AddSource(this.gridId, this);
        }

        public string GridId { get; private set; }

        private void StartWebServer()
        {
            try
            {
                WebApp.Start<OwinBootStrapper>(url: hostingAddress);

            }
            catch (Exception e)
            {
                throw;
            }

        }

        public void Start()
        {
            StartWebServer();
        }
        public void AttachClient(IClient client)
        {
            this.client = client;
        }

        public void GetComponentSpec()
        {
            GridComponentSpecResponse gridComponentSpec = new GridComponentSpecResponse() { RunTimeId = GridId,Type = "Solar Bodies"};
            gridComponentSpec.GridId = GridId;
            client.ReceiveGridComponentSpec(gridComponentSpec);
        }

        public void GetGridSpec()
        {
            GridSpecResponse gridSpec = new GridSpecResponse()
            {
                GridId = GridId,
                HeadersHeight = 22,
                RowHeight = 20,
            };

            // Recheck this logic.
            var visibleColumns = CarinaSnapShotBuilder.Columns;
            gridSpec.Columns = visibleColumns;

            client.ReceiveGridSpec(gridSpec);
        }

        public void ProcessSnapshotRequests(WebGridRequest request)
        {
            queue.Enqueue(() =>
            {
                WebGridRequest lastRequest;
                requests.TryGetValue(request.RequestId, out lastRequest);
                if (lastRequest != null && lastRequest.RequestId > request.RequestId) return;
                requests[request.RequestId] = request;

                if(request is UpdateViewPortRequest)
                {
                    var snapshotRequest = (UpdateViewPortRequest)request;
                    if (snapshotRequest.VerticalViewport == null && snapshotRequest.HorizontalViewport == null)
                        return;

                    var snapsot = CarinaSnapShotBuilder.GetSnapShot(snapshotRequest.VerticalViewport);
                    snapsot.VerticalViewport = new ViewPort() {Count = this.totalRowCount,Offset = snapshotRequest.VerticalViewport.Offset,Size = snapshotRequest.VerticalViewport.Size };
                    snapsot.GridId = this.gridId;
                    
                    this.client.ReceiveSnapshot(snapsot);
                }
            });
        }
    }
}
