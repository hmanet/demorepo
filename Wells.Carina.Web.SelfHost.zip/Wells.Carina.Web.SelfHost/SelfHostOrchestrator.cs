﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wells.Carina.Web.Presentation.ViewModel;
using Wells.Derivatives.Carina.Core.Metadata;

using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Showcase;


namespace Wells.Carina.Web.SelfHost
{
    public class SelfHostOrchestrator
    {
        private MockWebGridSource mockWebGridSource;
       

        public SelfHostOrchestrator()
        {
            mockWebGridSource = new MockWebGridSource(10000);
        }

        public void Orchestrate()
        {
         mockWebGridSource.Start();   
        }
    }
}
