﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using CefSharp;
using CefSharp.Wpf;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using Wells.Derivatives.Carina.Core.Command;
using Wells.Derivatives.Carina.Core.Presentation.Chart;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.OptionSelector;
using Wells.Derivatives.Carina.Core.Visualization;

namespace Wells.Carina.Web.Presentation.View
{
        public class WebLightGridControl : Control
        {
            static WebLightGridControl()
            {
                DataContextProperty.OverrideMetadata(typeof(WebLightGridControl), new FrameworkPropertyMetadata((d, a) => ((WebLightGridControl)d).OnDataContextChanged(a.OldValue, a.NewValue), (d, v) => v));
                if (Cef.IsInitialized) return;
                // Fix for occasional failure to find cef dependencies.
                var cefSettings = new CefSettings { BrowserSubprocessPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CefSharp.BrowserSubprocess.exe") };

                Cef.Initialize(cefSettings, false, true);

                
            }

        private void WebLightGridControl_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.O)
            {
                webBrowser.ShowDevTools();
            }
            else
            {
                webBrowser.CloseDevTools();
            }
        }

        private void OnDataContextChanged(object oldValue, object newValue)
        {
            SetupContextMenu();
        }

        public WebLightGridControl()
            {
               
                ApplyTemplate();
            }
            public override void OnApplyTemplate()
            {
            
            base.OnApplyTemplate();
            this.KeyDown += WebLightGridControl_KeyDown;
            webBrowser = (ChromiumWebBrowser)Template.FindName("ChromiumWebBrowser", this);
                //webBrowser.RegisterAsyncJsObject("chart", this);

                webBrowser.LoadingStateChanged += WebBrowserLoadingStateChanged;
                webBrowser.FrameLoadEnd += WebBrowserFrameLoadEnd;

                webBrowser.Address = string.Format("file:///{0}\\..\\..\\WebLightGrid\\{1}", Directory.GetCurrentDirectory(), SCRIPTFILE);
            }
            

            public static readonly DependencyProperty ScriptFileProperty = DependencyProperty.Register("ScriptFile", typeof(string), typeof(WebLightGridControl), new PropertyMetadata(SCRIPTFILE, OnScriptFileChanged));
            public string ScriptFile
            {
                get { return (string)GetValue(ScriptFileProperty); }
                set { SetValue(ScriptFileProperty, value); }
            }
            private static void OnScriptFileChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
            {
                if (e.NewValue == null) return;
                var vc = (WebLightGridControl)d;
                if (vc.webBrowser == null) return;
                vc.webBrowser.Address = string.Format("file:///{0}\\..\\..\\WebLightGrid\\{1}", Directory.GetCurrentDirectory(), e.NewValue);
                //log.Info("[CarinaChart] Url changed to " + vc.webBrowser.Address);
            }

            
            private bool browserLoaded;
            private void WebBrowserFrameLoadEnd(object sender, FrameLoadEndEventArgs e)
            {
                if (!e.Frame.IsMain) return;

                browserLoaded = true;
                //if (ShowDevToolsCommand == null) DispatcherInvoke(Initialize);
            }

            private void WebBrowserLoadingStateChanged(object sender, LoadingStateChangedEventArgs e)
            {
                if (e.IsLoading) return;
                DispatcherInvoke(Initialize);
            }

            private void DispatcherInvoke(Action action)
            {
                if (Dispatcher.CheckAccess())
                {
                    action.Invoke();
                    return;
                }

                Dispatcher.BeginInvoke(action);
            }


            private bool IsBrowserLoaded()
            {
                if (webBrowser.IsBrowserInitialized == false || webBrowser.IsLoaded == false || browserLoaded == false) return false;

                return true;
            }

            private void Initialize()
            {
                if (DataContext == null || !IsBrowserLoaded()) return;

                webBrowser.LoadingStateChanged -= WebBrowserLoadingStateChanged;
                webBrowser.FrameLoadEnd -= WebBrowserFrameLoadEnd;
            }

        public CarinaCommand ShowDevToolsCommand { get; set; }
        private void SetupContextMenu()
        {
            MenuItem item = new MenuItem();
            item.Header = "DevTools";
            item.Click += Item_Click;
            ContextMenu.Items.Add(item);
        }

            private bool isShowDeveloperTools;
        private void Item_Click(object sender, RoutedEventArgs e)
        {
            if(!isShowDeveloperTools)
                webBrowser.ShowDevTools();
            else
            {
                webBrowser.CloseDevTools();
            }

            isShowDeveloperTools = !isShowDeveloperTools;
        }

        
        private string initialCommand;
            private object[] initialCommandArgs;
            private const string SCRIPTFILE = "";
            //private static readonly ILog log = LogManager.GetLogger(typeof(CarinaChart));
            private static readonly string jslibraryprefix = "cv";
            private static readonly JsonSerializerSettings serializerSettings = new JsonSerializerSettings { DateFormatString = Plottable.DateTimeFormat };
            private ChromiumWebBrowser webBrowser;
        }
    }

