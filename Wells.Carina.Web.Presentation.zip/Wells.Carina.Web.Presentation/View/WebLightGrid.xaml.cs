﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CefSharp;
using Path = System.IO.Path;

namespace Wells.Carina.Web.Presentation.View
{
    /// <summary>
    /// Interaction logic for WebLightGrid.xaml
    /// </summary>
    public partial class WebLightGrid : UserControl
    {
        public WebLightGrid()
        {
            InitializeComponent();
            //Browser.ShowDevTools();
            //var cefSettings = new CefSettings { BrowserSubprocessPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CefSharp.BrowserSubprocess.exe") };
            //Cef.Initialize(cefSettings, false, true);
            this.DataContextChanged += WebLightGrid_DataContextChanged;
            //Browser.IsBrowserInitializedChanged += Browser_IsBrowserInitializedChanged;
        }

        private void Browser_IsBrowserInitializedChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            //CefSettings s = new CefSettings();
            //s.SetOffScreenRenderingBestPerformanceArgs();
            //Cef.Initialize(s);
            //Browser.ShowDevTools();
        }

        private void WebLightGrid_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
           
        }

        private void Browser_OnFrameLoadEnd(object sender, FrameLoadEndEventArgs e)
        {
            
        }
    }
}
