﻿using Wells.Derivatives.Carina.Core.Host;
using Wells.Derivatives.Carina.Core.Presentation.Grid;

namespace Wells.Carina.Web.Presentation.ViewModel
{
    public class WebLightGridMediator : IParentChildMediator<GridComponentViewModel, WebLightGridViewModel>
    {
        public void Mediate(GridComponentViewModel parent, WebLightGridViewModel child)
        {
            chart = child;
            child.Initialize(parent.GridType, parent.ComponentTitle, parent.ComponentName, parent.Grid);
        }

        public void Dispose()
        {
            chart.Dispose();
        }

        private WebLightGridViewModel chart;
    }
}
