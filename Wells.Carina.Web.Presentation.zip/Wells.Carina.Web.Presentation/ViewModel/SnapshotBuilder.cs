﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Responses;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Carina.Web.Presentation.ViewModel
{
    public class SnapshotBuilder
    {
        private GridViewModel gridViewModel;
        private string gridId;
        public SnapshotBuilder(string gridId,GridViewModel gridViewModel)
        {
            this.gridViewModel = gridViewModel;
            this.gridId = gridId;
        }

        public SnapshotResponse Build()
        {
            SnapshotResponse snapshot = new SnapshotResponse();

            snapshot.VerticalViewport = new ViewPort(){Size = gridViewModel.Tree.ViewportSize,Offset = gridViewModel.Tree.ViewportOffset,Count = gridViewModel.Tree.TotalCount};
            snapshot.HorizontalViewport = new ViewPort(){ Size = gridViewModel.ViewportSize, Offset = gridViewModel.ViewportOffset, Count = gridViewModel.Columns.Count(m=>m.Visible) };

            snapshot.Columns = new List<LightGridColumn>();
            snapshot.GridId = this.gridId;
            // Recheck this logic.
            var visibleColumns = this.gridViewModel.Spec.GroupingModeColumns.VisibleColumns;

            foreach(var column in visibleColumns)
            {
                var col = new LightGridColumn();
                col.Visible = column.Visible;
                col.Background = column.Background.ToString();
                if (column.DecimalPlaces != null) col.DecimalPlaces = column.DecimalPlaces.Value;
                col.Editable = column.Editable;
                col.FontFamily = column.FontFamily.Source;
                col.FontSize = column.FontSize.ToString();
                col.FontStyle = column.FontStyle.ToString();
                col.FontWeight = column.FontWeight.ToString();
                col.Foreground = column.Foreground.ToString();
                col.Name = column.Name;
                col.CellBorder = "0";
                col.Width = column.Width;
                
                snapshot.Columns.Add(col);
            }

            snapshot.Cells = new List<LightGridCell>();
            int rowIndex = 0;
            foreach (var row in this.gridViewModel.Tree.Nodes)
            {
                var columnIndex=0;
                foreach (ColumnSpec column in visibleColumns)
                {
                    var cell = new LightGridCell();
                    cell.Data = row.Data[column.Key];
                    cell.ColumnIndex = columnIndex++;
                    cell.RowIndex = rowIndex;
                    cell.Left = column.Left;
                    cell.Top = row.Top;
                    snapshot.Cells.Add(cell);
                }

                rowIndex++;
            }
            
            return snapshot;
            
        }
    }
}
