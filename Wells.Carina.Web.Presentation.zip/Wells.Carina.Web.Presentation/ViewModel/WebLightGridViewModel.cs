﻿using System;
using System.IO;
using System.Net.Http;
using Microsoft.Owin.Hosting;
using Wells.Derivatives.Carina.Core.Interfaces;
using Wells.Derivatives.Carina.Core.Presentation.Common;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Carina.Web.Presentation.ViewModel
{

    public class WebLightGridViewModel : CarinaViewModelBase
    {
        private string hostingAddress = "http://localhost:9000/";

        private string homePage = "Component.html";

        private string webPage;
        public WebLightGridViewModel(IComponentContext componentContext)
            : base(componentContext)
        {
            StartOwinWebServer();
        }

        private void StartOwinWebServer()
        {
            try
            {
                WebServer.UrlAddress = hostingAddress;
                WebServer.Start();

              WebPage = homePage;
            }
            catch (Exception e) 
            {
               
                throw;
            }
            
        }

        public string WebPage
        {
            get { return webPage; }
            set
            {
                if (webPage != value)
                {
                    webPage = value;
                    RaisePropertyChanged();
                }
            }
        }

        public void Initialize(string gridType, string gridTitle, string gridName, GridViewModel parent)
        {
            parent.Tree.EndChanges += Tree_EndChanges;
        }

        private void Tree_EndChanges()
        {
            throw new NotImplementedException();
        }

        public override string ComponentTitle { get { return "WebLightGrid"; } }
    }
}
