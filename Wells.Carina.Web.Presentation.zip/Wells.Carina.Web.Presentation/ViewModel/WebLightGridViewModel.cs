﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using Microsoft.Owin.Hosting;
using Wells.Carina.Web.API;
using Wells.Carina.Web.API.Hubs;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Requests;
using Wells.Carina.Web.API.Models.Responses;
using Wells.Derivatives.Carina.Core.Interfaces;
using Wells.Derivatives.Carina.Core.Presentation.Common;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Threading;

namespace Wells.Carina.Web.Presentation.ViewModel
{
    public class WebLightGridViewModel : CarinaViewModelBase,IWebLightGridSource
    {
        public WebLightGridViewModel(IComponentContext componentContext)
            : base(componentContext)
        {
            //lock(CarinaHubBase.gridsById) gridsById[id] = this;

            //var handler = new RequestsHandler(gridsById);
            this.gridId = "12345";
            WebLightGridSources.AddSource(this.gridId,this);

        }

        //public static WebLightGridViewModel TryGetById(string id)
        //{
        //    lock (gridsById)
        //    {
        //        WebLightGridViewModel value;
        //        gridsById.TryGetValue(id, out value);
        //        return value;
        //    }
        //}
        private string gridId;
        //private static readonly Dictionary<string, WebLightGridViewModel> gridsById = new Dictionary<string, WebLightGridViewModel>();

        private string hostingAddress = "http://localhost:9000/";

        private string homePage = "Component.html";

        private string webPage;

        private GridViewModel parent;

        private IClient client;

        private BackgroundQueue<Action> queue = BackgroundQueue<Action>.Single(x => x());

        private Dictionary<int, WebGridRequest> requests = new Dictionary<int, WebGridRequest>();

        private RequestProcessor requestProcessor;

        private SnapshotBuilder snapshotBuilder;

        private bool isClientConnected;

        private string gridType;

        private void StartWebServer()
        {
            try
            {
              WebServer.UrlAddress = hostingAddress;
              WebServer.Start();

              WebPage = homePage;
            }
            catch (Exception e) 
            {
                throw;
            }
            
        }

        public string WebPage
        {
            get { return webPage; }
            set
            {
                if (webPage != value)
                {
                    webPage = value;
                    RaisePropertyChanged();
                }
            }
        }

        public string GridId { get {return gridId;} }

        public void Initialize(string gridType, string gridTitle, string gridName, GridViewModel parent)
        {
            this.parent = parent;
            this.gridType = gridType;
            this.StartWebServer();
            requestProcessor = new RequestProcessor(this.parent);
            snapshotBuilder = new SnapshotBuilder(this.gridId,this.parent);
            parent.Tree.EndChanges += Tree_EndChanges;
        }

        private void Tree_EndChanges()
        {
            queue.Enqueue(() =>
            {
            if (!string.IsNullOrEmpty(this.gridId) && WebLightGridSources.GetSource(this.gridId) != null)
            {
                var snapShot = snapshotBuilder.Build();

                this.client.ReceiveSnapshot(snapShot);
            }
            });
        }

        

        public void AttachClient(IClient client)
        {
            isClientConnected = true;
            this.client = client;
        }

        public void GetComponentSpec()
        {
            if (!isClientConnected)
                return;

            GridComponentSpecResponse gridComponentSpec = new GridComponentSpecResponse()
            {
                RunTimeId = this.GridId,Type = this.gridType,GridId = this.GridId
            };

            this.client.ReceiveGridComponentSpec(gridComponentSpec);
        }

        public void GetGridSpec()
        {
            if (!isClientConnected)
                return;

            GridSpecResponse gridSpec = new GridSpecResponse()
            {
                GridId = this.GridId,
                HeadersHeight = (int)this.parent.HeadersHeight,
                RowHeight = (int)this.parent.RowHeight,
            };

            gridSpec.Columns = new List<LightGridColumn>();
            // Recheck this logic.
            var visibleColumns = this.parent.Spec.GroupingModeColumns.VisibleColumns;

            foreach (var column in visibleColumns)
            {
                var col = new LightGridColumn();
                col.Visible = column.Visible;
                col.Background = column.Background.ToString();
                if (column.DecimalPlaces != null) col.DecimalPlaces = column.DecimalPlaces.Value;
                col.Editable = column.Editable;
                col.FontFamily = column.FontFamily.Source;
                col.FontSize = column.FontSize.ToString();
                col.FontStyle = column.FontStyle.ToString();
                col.FontWeight = column.FontWeight.ToString();
                col.Foreground = column.Foreground.ToString();
                col.Name = column.Name;
                col.CellBorder = "0";
                col.Width = column.Width;

                gridSpec.Columns.Add(col);
            }

            this.client.ReceiveGridSpec(gridSpec);
        }

        public void ProcessSnapshotRequests(WebGridRequest request)
        {
            queue.Enqueue(() =>
            {
                WebGridRequest lastRequest;
                requests.TryGetValue(request.RequestId, out lastRequest);
                if (lastRequest != null && lastRequest.RequestId > request.RequestId) return;
                requests[request.RequestId] = request;

                requestProcessor.Process(request);
               
            });
        }

        public override string ComponentTitle { get { return "WebLightGrid"; } }


        protected override void ComponentDispose(bool disposing)
        {
            WebLightGridSources.RemoveSource(this.gridId);

            this.gridId = null;
            base.ComponentDispose(disposing);
        }

        
    }
}
