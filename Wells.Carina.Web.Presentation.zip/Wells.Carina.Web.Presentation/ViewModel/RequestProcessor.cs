﻿using Wells.Carina.Web.API.Models.Requests;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Carina.Web.Presentation.ViewModel
{
    public class RequestProcessor
    {
        private GridViewModel gridViewModel;

        public RequestProcessor(GridViewModel gridViewModel)
        {
            this.gridViewModel = gridViewModel;
        }

        public void Process(WebGridRequest request)
        {
            // Need to implement a proper Visitor.

            if(request is SnapshotRequest)
                Visit(request as SnapshotRequest);
            else if (request is UpdateViewPortRequest)
                Visit(request as UpdateViewPortRequest);
        }

        private void Visit(SnapshotRequest snapShotRequest)
        {
            if (snapShotRequest.ViewPort.Offset > 0)
            {
                gridViewModel.Tree.ViewportOffset = snapShotRequest.ViewPort.Offset;
                gridViewModel.Tree.ViewportSize = snapShotRequest.ViewPort.Size;
            }
            else
            {
                gridViewModel.Tree.ViewportOffset = 1;
            }
            
        }

        private void Visit(UpdateViewPortRequest updateViewPortRequest)
        {
            if (updateViewPortRequest.VerticalViewport != null)
            {
                gridViewModel.Tree.ViewportOffset = updateViewPortRequest.VerticalViewport.Offset;
                gridViewModel.Tree.ViewportSize = updateViewPortRequest.VerticalViewport.Size;
            }

            else if (updateViewPortRequest.HorizontalViewport != null)
            {
                gridViewModel.ViewportOffset = updateViewPortRequest.HorizontalViewport.Offset;
            }
        }

    }
}
