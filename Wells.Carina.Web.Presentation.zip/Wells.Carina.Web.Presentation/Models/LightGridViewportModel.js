"use strict";
class LightGridViewportModel {
    constructor(model) {
        this.Cells = model.Cells;
        this.Columns = model.Columns;
        this.Name = model.Name;
        this.RowHeight = model.RowHeight;
    }
}