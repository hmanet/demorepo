function LightGridColumn(data)
 {
    var styleInfo=data.FormatInfo;
    this.Data = data.Name;
    this.Height=data.Height;
    this.Width=data.Width;
    this.Background =styleInfo.Background;
    this.Editable =styleInfo.Editable;
    this.FontFamily=styleInfo.FontFamily;
    this.FontStyle=styleInfo.FontStyle;
    this.FontSize=styleInfo.FontSize;
    this.FontWeight=styleInfo.FontWeight;
    this.Foreground=styleInfo.Foreground;
     this.TextUnderline=styleInfo.Underline;
    this.TextStrikethrough=styleInfo.Strikethrough;
    this.Visible=styleInfo.Visible;
}
function LightGridHeader(id,data,width,height,background,offsetleft,offsettop,textalign,display){
    this.Id = id || 0;
    this.Data = data;
    this.Width = width;
    this.Height = height;
    this.OffsetLeft = offsetleft ? offsetleft : 0;
    this.OffsetTop = offsettop ? offsettop : 0;
    this.Background = background ? background : "#343434";
    this.TextAlign = textalign ? textalign : "left";
     
}

