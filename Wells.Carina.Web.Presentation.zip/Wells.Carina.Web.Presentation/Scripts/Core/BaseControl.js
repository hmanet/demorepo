"use strict";
{
    Carina.Core.BaseControl = class 
    {
        constructor()
        {
            this.dataContext = null;
            this.element = null;
        }

        get DataContext() { return this.dataContext; }
        set DataContext(value)
        {
            let oldValue = this.dataContext;
            this.dataContext = value;
            this.OnDataContextChanged(oldValue, value);
        }
        OnDataContextChanged(oldValue, newValue){}

        get Element() { return this.element; }
        set Element(value) { this.element = value; }
    }

    Carina.Core.BaseComponent = class extends Carina.Core.BaseControl
    {
        constructor()
        {
            super();
        }
    }
}