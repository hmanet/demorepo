"use strict";
{
    Carina.Core.UiUtil = class
    {
        static CalculateViewportResolution()
        {
            let width = Math.round((window.innerWidth) * (0.6));
            let height = Math.round((window.innerHeight) * 0.92);
            return new Size(width, height);
        }

        static RemoveChildren(node)
        {
            let firstChild = node.firstChild;
            while (firstChild)
            {
                node.removeChild(firstChild);
                firstChild = node.firstChild;
            }
        }
    }
}