"use strict";
{
    let Model = Carina.Model;

    Carina.Core.UiUtil = class
    {
        static CalculateViewportResolution()
        {
            let width = Math.ceil(window.innerWidth);
            let height = Math.ceil(window.innerHeight);
            return new Model.Size(width, height);
        }

        static RemoveChildren(node)
        {
            let firstChild = node.firstChild;
            while (firstChild)
            {
                node.removeChild(firstChild);
                firstChild = node.firstChild;
            }
        }

        static Debounce(callback, delay)
        {
            return _.debounce(callback, delay ? delay : 100);
        }

        static Throttle(callback, delay)
        {
            return _.throttle(callback, delay ? delay : 100);
        }
    }
}