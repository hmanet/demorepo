﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;

    Carina.Model.TreeSource = class
    {
        constructor(server)
        {
            this.server = server;

            this.onStarted_Handler = this.OnStarted.bind(this);
            this.onGridComponentSpecReceived_Handler = this.OnGridComponentSpecReceived.bind(this);
            this.onSnapshotReceived_handler = _.throttle(this.OnSnapshotReceived.bind(this), 10, { trailing: true, leading: false }).bind(this);

            this.server.started.Add(this.onStarted_Handler);
            this.server.ReceivedEventAjax.Add("GetGridComponentSpec", this.onGridComponentSpecReceived_Handler);
            this.server.ReceivedEvent.Add("recieveSnapShot", this.onSnapshotReceived_handler);

            this.Started = new Core.CarinaEvent();
            this.ComponentSpecReceived = new Core.CarinaEvent();
            this.SnapshotReceived = new Core.CarinaEvent();
        }

        Start()
        {
            this.server.Start();
        }
        OnStarted()
        {
            this.Started.Invoke();
        }

        GetGridComponentSpec()
        {
            this.server.SendAjax("GetGridComponentSpec");
        }
        OnGridComponentSpecReceived(spec)
        {
            this.ComponentSpecReceived.Invoke(spec);
        }

        GetSnapShot(viewPort)
        {
            this.server.Send("getSnapShot", this.CreateSnapshotRequest(viewPort));
        }
        OnSnapshotReceived(value)
        {
            this.SnapshotReceived.Invoke(value);
        }
        CreateSnapshotRequest(viewport)
        {
            return {
                "name": "getSnapShot",
                "viewPort": { "count": viewport.Count, "size": viewport.Size, "offset": viewport.Offset }
            };
        }

        Dispose()
        {
            this.server.started.Remove(this.onStarted_Handler);
            this.server.ReceivedEventAjax.Remove("GetGridComponentSpec", this.onGridComponentSpecReceived_Handler);
            this.server.ReceivedEvent.Remove("recieveSnapShot", this.onSnapshotReceived_handler);
        }
    }
}