﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;

    Carina.Model.TreeSource = class
    {
        constructor(server)
        {
            this.server = server;

            this.onStarted_Handler = this.OnStarted.bind(this);
            this.onComponentSpecReceived_Handler = this.OnComponentSpecReceived.bind(this);
            this.onGridSpecReceived_Handler = this.OnGridSpecReceived.bind(this);
            this.onSnapshotReceived_handler = this.OnSnapshotReceived.bind(this);
            
            this.server.started.Add(this.onStarted_Handler);
            this.server.ReceivedEvent.Add("receiveSnapShot", this.onSnapshotReceived_handler);
            this.server.ReceivedEvent.Add("receiveGridComponentSpec", this.onComponentSpecReceived_Handler); // TODO:
            this.server.ReceivedEvent.Add("receiveGridSpec", this.onGridSpecReceived_Handler); // TODO:

            this.Started = new Core.CarinaEvent();
            this.ComponentSpecReceived = new Core.CarinaEvent();
            this.GridSpecReceived = new Core.CarinaEvent();
            this.SnapshotReceived = new Core.CarinaEvent();

            this.snapshotId = 1;
        }

        Start()
        {
            this.server.Start();
        }
        OnStarted()
        {
            this.Started.Invoke();
        }

        GetComponentSpec()
        {
            this.server.Send("getComponentSpec");
        }
        OnComponentSpecReceived(spec)
        {
            this.ComponentSpecReceived.Invoke(spec);
        }

        GetGridSpec()
        {
            this.server.Send("getGridSpec");
        }
        OnGridSpecReceived(spec)
        {
            this.GridSpecReceived.Invoke(spec);
        }

        GetSnapShot(updateViewportRequest)
        {
            updateViewportRequest.Id = this.snapshotId++;
            this.server.Send("getSnapShot", updateViewportRequest);
        }
        OnSnapshotReceived(value)
        {
            this.SnapshotReceived.Invoke(value);
        }

        Dispose()
        {
            this.server.started.Remove(this.onStarted_Handler);
            this.server.ReceivedEvent.Remove("receiveSnapShot", this.onSnapshotReceived_handler);
            this.server.ReceivedEvent.Remove("receiveGridComponentSpec", this.onComponentSpecReceived_Handler); // TODO:
            this.server.ReceivedEvent.Remove("receiveGridSpec", this.onGridSpecReceived_Handler); // TODO:
        }
    }
}