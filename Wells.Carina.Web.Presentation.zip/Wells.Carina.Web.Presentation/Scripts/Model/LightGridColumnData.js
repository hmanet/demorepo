"use strict";
function LightGridColumn(data)
 {
   // var styleInfo=data.FormatInfo;
    this.Data = data.Name;
    this.Height=data.Height;
    this.Width=data.Width;
    this.Background =data.Background;
    this.Editable =data.Editable;
    this.FontFamily=data.FontFamily;
    this.FontStyle=data.FontStyle;
    this.FontSize=data.FontSize;
    this.FontWeight=data.FontWeight;
    this.Foreground=data.Foreground;
    this.TextUnderline=data.Underline;
    this.TextStrikethrough=data.Strikethrough;
    this.Visible=data.Visible;
    this.Top=data.Top;
    this.Left=data.Left;
    this.CellBorder = data.CellBorder;
}

function LightGridHeader(id, data, width, height, background, offsetleft, offsettop, textalign, display)
{
    this.Id = id || 0;
    this.Data = data;
    this.Width = width;
    this.Height = height;
    this.OffsetLeft = offsetleft ? offsetleft : 0;
    this.OffsetTop = offsettop ? offsettop : 0;
    this.Background = background ? background : "#343434";
    this.TextAlign = textalign ? textalign : "left";
}

