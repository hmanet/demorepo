"use strict";
{
    Carina.Model.Snapshot = class
    {
        constructor(model)
        {
            this.Cells = model.Cells;
            this.Columns = model.Columns;
            this.Name = model.Name;
            this.RowHeight = model.RowHeight;
        }
    }
}