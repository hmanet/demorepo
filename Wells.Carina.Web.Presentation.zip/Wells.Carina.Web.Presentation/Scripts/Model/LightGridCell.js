"use strict"; 
{
    let Core = Carina.Core;
    
    Carina.Model.LightGridCell = class
    {
        constructor(cellData, data)
        {
            //var styleInfo=data.FormatInfo; 
            this.Height = data.Height;
            this.Width = data.Width;
            this.Background = data.Background;
            this.Editable = data.Editable;
            this.FontFamily = data.FontFamily;
            this.FontStyle = data.FontStyle;
            this.FontSize = data.FontSize;
            this.FontWeight = data.FontWeight;
            this.Foreground = data.Foreground;
            this.TextUnderline = data.Underline;
            this.TextStrikethrough = data.Strikethrough;
            this.Visible = data.Visible;
            this.Position = "absolute";
            this.Top = data.Top;
            this.Left = data.Left;
            this.CellBorder = data.CellBorder;
            this.Data = cellData;
        }
    } 
}
