"use strict";

function GridComponentSpec(gridType, gridRuntimeId, rowHeight, headersHeight, columns)
{
    this.GridType = gridType;
    this.GridRuntimeId = gridRuntimeId;
    this.RowHeight = rowHeight;
    this.HeadersHeight = headersHeight;
    this.Columns = columns;
}
