"use strict";

function GridComponentSpec(gridType, gridRuntimeId, rowHeight, columnHeaderHeight, columns)
{
    this.GridType = gridType;
    this.GridRuntimeId = gridRuntimeId;
    this.RowHeight = rowHeight;
    this.ColumnHeaderHeight = columnHeaderHeight;
    this.Columns = columns;
}
