﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;

    Carina.Model.TreeBuilderModel = class
    {
        constructor(source)
        {
            this.snapshot = null;
            this.source = source;
            this.SnapshotChanged = new Core.CarinaEvent();

            this.source_OnSnapshotReceived_Handler = this.Source_OnSnapshotReceived.bind(this);
            this.source.SnapshotReceived.Add(this.source_OnSnapshotReceived_Handler);
        }

        Source_OnSnapshotReceived(value)
        {
            this.Snapshot = value;
        }
        get Snapshot() { return this.snapshot; }
        set Snapshot(value)
        {
            this.snapshot = value;
            this.SnapshotChanged.Invoke(value);
        }

        Scroll(viewport)
        {
            this.source.GetSnapShot(viewport);
        }

        Dispose()
        {
            this.source.SnapshotReceived.Remove(this.source_OnSnapshotReceived_Handler);
        }
    }
}