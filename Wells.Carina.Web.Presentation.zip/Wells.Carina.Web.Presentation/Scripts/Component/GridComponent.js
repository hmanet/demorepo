"use strict";

class GridComponent
{
    constructor(source)
    {
        this.source = source;
        this.gridViewModel = new GridViewModel(source);
        this.gridControl = new LightGridControl(this.gridViewModel);

        this.source.Started.Add(this.OnSourceStarted.bind(this));
        
        this.source.Start();
    }

    OnSourceStarted()
    {
        this.source.GetGridComponentSpec();
    }
}

class GridViewModel
{
    constructor(source)
    {
        this.spec = null;
        this.snapshot = null;
        this.SnapshotChanged = new CarinaEvent();
        this.SpecChanged = new CarinaEvent();

        this.source = source;
        this.source.ComponentSpecReceived.Add(this.Source_OnComponentSpecReceived.bind(this));

        this.builder = new TreeBuilderModel(source);
        this.builder.SnapshotChanged.Add(this.Builder_OnSnapshotChanged.bind(this));
    }

    Source_OnComponentSpecReceived(newSpec)
    {
        this.Spec = newSpec;
    }
    get Spec()
    {
        return this.spec;
    }
    set Spec(value)
    {
        this.spec = value;
        this.SpecChanged.Invoke(value);
    }

    Scroll(viewport)
    {
        this.source.GetSnapShot(viewport);
    }

    Builder_OnSnapshotChanged(value)
    {
        this.Snapshot = value;
    }
    get Snapshot()
    {
        return this.snapshot;
    }
    set Snapshot(value)
    {
        this.snapshot = value;
        this.SnapshotChanged.Invoke(value);
    }
}

class TreeBuilderModel
{
    constructor(source)
    {
        this.snapshot = null;
        this.source = source;
        this.source.SnapshotReceived.Add(this.OnSnapshotReceived.bind(this));
        this.SnapshotChanged = new CarinaEvent();
    }

    OnSnapshotReceived(value)
    {
        this.Snapshot = value;
    }

    get Snapshot()
    {
        return this.snapshot;
    }
    set Snapshot(value)
    {
        this.snapshot = value;
        this.SnapshotChanged.Invoke(value);
    }
}