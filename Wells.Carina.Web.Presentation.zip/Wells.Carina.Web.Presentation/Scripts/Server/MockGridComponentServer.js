﻿"use strict";

function MockGridComponentServer()
{
    this.Send = function(key, value)
    {
        switch (key)
        {
            case "Viewport":
                setTimeout(() => { this.ReceivedEvent.Invoke("Snapshot", jsonData); }, 10);
                break;
        }
    };

    this.ReceivedEvent = new KeyedEvent();

    //this would naturally come from server during startup
    setTimeout(() => { this.ReceivedEvent.Invoke("GridComponentSpec", new GridComponentSpec()); }, 10);
}
