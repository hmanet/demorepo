{
    // Namespace import
    let Core = Carina.Core;
    let Model = Carina.Model;

    Carina.ViewModel.GridViewModel = class 
    {
        constructor(source)
        {
            this.spec = null;
            this.snapshot = null;
            this.SnapshotChanged = new Core.CarinaEvent();
            this.SpecChanged = new Core.CarinaEvent();

            this.source = source;
            this.source_OnComponentSpecReceived_Handler = this.Source_OnComponentSpecReceived.bind(this);
            this.source.ComponentSpecReceived.Add(this.source_OnComponentSpecReceived_Handler);

            this.builder = new Model.TreeBuilderModel(source);
            this.builder_OnSnapshotChanged_Handler = this.Builder_OnSnapshotChanged.bind(this);
            this.builder.SnapshotChanged.Add(this.builder_OnSnapshotChanged_Handler);
        }

        Source_OnComponentSpecReceived(newSpec)
        {
            this.Spec = newSpec;
        }
        get Spec() { return this.spec; }
        set Spec(value)
        {
            let oldValue = this.spec;
            this.spec = value;
            this.SpecChanged.Invoke({ OldValue: oldValue, NewValue: value});
        }

        Builder_OnSnapshotChanged(value)
        {
            this.Snapshot = value;
        }
        get Snapshot() { return this.snapshot; }
        set Snapshot(value)
        {
            this.snapshot = value;
            this.SnapshotChanged.Invoke(value);
        }

        Scroll(viewport)
        {
            this.builder.Scroll(viewport);
        }

        Dispose()
        {
            this.source.ComponentSpecReceived.Remove(this.source_OnComponentSpecReceived_Handler);
            this.builder.SnapshotChanged.Remove(this.builder_OnSnapshotChanged_Handler);
        }
    }
}