"use strict";
{
    // Namespace import
    let Vm = Carina.ViewModel;

    Carina.ViewModel.GridComponetViewModel = class
    {
        constructor(source)
        {
            this.gridViewModel = new Vm.GridViewModel(source);

            this.source = source;
            this.source_OnStarted_Handler = this.Source_OnStarted.bind(this);
            this.source.Started.Add(this.source_OnStarted_Handler);
            this.source.Start();
        }

        get GridViewModel() { return this.gridViewModel; }

        Source_OnStarted()
        {
            this.source.GetGridComponentSpec();
        }

        Dispose()
        {
            this.source.Started.Remove(this.source_OnStarted_Handler);
        }
    }
}