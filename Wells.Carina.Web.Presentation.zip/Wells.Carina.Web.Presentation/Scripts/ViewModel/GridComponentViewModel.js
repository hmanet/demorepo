"use strict";
{
    // Namespace import
    let Vm = Carina.ViewModel;

    Carina.ViewModel.GridComponetViewModel = class
    {
        constructor(source)
        {
            this.gridViewModel = new Vm.GridViewModel(source);

            this.source = source;

            this.source_OnStarted_Handler = this.Source_OnStarted.bind(this);
            this.source.Started.Add(this.source_OnStarted_Handler);

            this.source_ComponentSpecReceived_Handler = this.Source_ComponentSpecReceived.bind(this);
            this.source.ComponentSpecReceived.Add(this.source_ComponentSpecReceived_Handler);

            this.source.Start();
        }

        get GridViewModel() { return this.gridViewModel; }

        Source_OnStarted()
        {
            this.source.GetComponentSpec();
        }

        Source_ComponentSpecReceived()
        {
            this.source.GetGridSpec();
        }

        Dispose()
        {
            this.source.Started.Remove(this.source_OnStarted_Handler);
            this.source.ComponentSpecReceived.Remove(source_ComponentSpecReceived_Handler);
        }
    }
}