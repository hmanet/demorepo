﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;

    Carina.LightGrid.LightGridHeader = class extends Core.BaseControl
    {
        constructor(lightGridPanel)
        {
            super();

            this.Parent = lightGridPanel;
            this.Element = document.createElement("div");
            this.Element.setAttribute("name", "LightGridHeader");
            this.Element.style["overflow"] = "hidden";
            this.Element.style["position"] = "absolute";
            this.Element.style["z-index"] = LightGrid.LightGrid.HeaderZIndex;
        }

        Reset()
        {
            this.Height = this.Parent.Spec.HeadersHeight;
            Core.UiUtil.RemoveChildren(this.Element);
        }

        Render(snapshot)
        {
            if (snapshot.Columns.length <= 0) return;

            // let headerSize = new LightGrid.LightGridColumnHeader(this.Parent.Spec, snapshot.Columns);
            // this.Width = headerSize.width;

            let totalWidth = 0;
            let headerElements = [];
            let headerLeft = 0, count = 0;
            for (let index = 0; index < snapshot.Columns.length; index++)
            {
                totalWidth += snapshot.Columns[index].Width;

                if (index > 0)
                {
                    headerLeft += snapshot.Columns[index - 1].Width;
                }

                var header = new LightGrid.LightGridColumnHeader(snapshot.Columns[index]);
                header.Height = this.Parent.Spec.HeadersHeight;
                header.Style("top", "0px");
                header.Style("left", headerLeft + "px");
                header.Render();
                this.Element.appendChild(header.Element);

                //let cellData = snapshot.Columns[index];
                //cellData["Height"] = this.Height;
                //cellData["Top"] = "0px";
                //if (index)
                //{
                //    headerLeft += snapshot.Columns[index - 1].Width;
                //}

                //cellData["Left"] = headerLeft;
                //count += 1;
                //let cell = new LightGridColumn(cellData);
                //let element = new LightGrid.LightGridCell(cell);
                //headerElements.push(element);
            }

            this.Width = totalWidth;

            //for (let index = 0; index < headerElements.length; index++)
            //{
            //    this.Element.appendChild(headerElements[index].Element);
            //}
        }
    }
}