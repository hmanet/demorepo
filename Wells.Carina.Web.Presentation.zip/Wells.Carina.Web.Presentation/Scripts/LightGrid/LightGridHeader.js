﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;

    Carina.LightGrid.LightGridHeader = class extends Core.BaseControl
    {
        constructor(lightGridPanel)
        {
            super();

            this.Parent = lightGridPanel;
            this.Element = document.createElement("div");
            this.height = 0;
        }

        Reset()
        {
            this.height = this.Parent.Spec.ColumnHeaderHeight;
            this.Element.style["height"] = this.Parent.Spec.ColumnHeaderHeight.toString() + "px";
            this.Element.style["overflow"] = "hidden";
            this.Element.style["position"] = "relative";
            Core.UiUtil.RemoveChildren(this.Element);
        }

        Render(snapshot)
        {
            if (snapshot.Columns.length <= 0) return;

            let headerSize = CalculateHeaderResolution(this.Parent.Spec, snapshot.Columns);
            this.Element.style["width"] = headerSize.width + "px";

            let headerElements = [];
            let headerLeft = 0, count = 0;
            for (let index = 0; index < snapshot.Columns.length; index++)
            {
                let cellData = snapshot.Columns[index];
                cellData["Height"] = this.height;
                cellData["Top"] = "0px";
                if (index)
                {
                    headerLeft += snapshot.Columns[index - 1].Width;
                }

                cellData["Left"] = headerLeft;
                count += 1;
                let cell = new LightGridColumn(cellData);
                let element = CreateCell(cell);
                headerElements.push(element);
            }

            for (let index = 0; index < headerElements.length; index++)
            {
                this.Element.appendChild(headerElements[index]);
            }
        }
    }
}