﻿"use strict";
{
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;

    //LightGrid.LightGridColumnHeader = class extends Core.BaseControl
    //{
    //    constructor(gridSpec, columnData)
    //    {
    //        let sizes = {};
    //        let width = 0;
    //        for (let index = 0; index < columnData.length; index++)
    //        {
    //            width += columnData[index].Width;
    //        }
    //        let height = gridSpec.HeadersHeight;
    //        //added '10', purpose of height 
    //        sizes["width"] = width;
    //        sizes["height"] = height;
    //        return sizes;
    //    }
    //}

    Carina.LightGrid.LightGridColumnHeader = class extends Core.BaseControl
    {
        constructor(columnSpec)
        {
            super();
            this.Element = document.createElement("div");
            this.columnSpec = columnSpec;
            this.cellData = null;
            this.Element.setAttribute("id", columnSpec.Id);
            this.Style("position", "absolute");
            this.Style("display", "inline-block");
        }

        Render()
        {
            //if (this.CompareCellData(this.cellData, cellData))
            //    return;

            //this.cellData = cellData;

            //column.Top = cellData.Top;
            //column.Left = cellData.Left;
            //if (cellData.FormatInfo)
            //{
            //    cellData.FormatInfo.Top = cell.Top;
            //    cellData.FormatInfo.Left = cell.Left;
            //}
            //let cellObj = new Carina.Model.LightGridCell(cell.Data, cell.FormatInfo ? cell.FormatInfo : column);
            //let cell = new LightGrid.CreateCell(cellObj);
            //cell.setAttribute("id", cell.ColumnIndex.toString() + cell.RowIndex.toString());

            //this.Style("top", cell.Top + "px");
            // this.Style("left", cell.Left + "px");

            this.Width = this.columnSpec.Width;

            this.Style("color", this.columnSpec.Foreground);
            this.Style("backgroundColor", this.columnSpec.Background);
            this.Style("font-family", this.columnSpec.FontFamily);
            this.Style("font-style", this.columnSpec.FontStyle);
            this.Style("font-weight", this.columnSpec.FontWeight);
            this.Style("visibility", this.columnSpec.Visible);
            this.Style("font-size", this.columnSpec.FontSize);
            this.Style("border", this.columnSpec.CellBorder );
            // this.Style("overflow", "hidden");
            this.Element.innerText = this.columnSpec.Name;
            //return cell;
        }

        CompareCellData(cellData)
        {
            return this.cellData.Height == cellData.Height && this.cellData.Text == cellData.Text;
        }
    }
}
