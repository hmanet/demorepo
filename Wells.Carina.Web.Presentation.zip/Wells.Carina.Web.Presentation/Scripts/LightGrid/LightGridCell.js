"use strict";
{
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;

    Carina.LightGrid.LightGridCell = class extends Core.BaseControl
    {

        constructor()
        {
            super();
        }
        CellRender(cell, column)
        {
            column.Top = cell.Top;
            column.Left = cell.Left;
            if (cell.FormatInfo)
            {
                cell.FormatInfo.Top = cell.Top;
                cell.FormatInfo.Left = cell.Left;
            }
            var cellObj = new Carina.Model.LightGridCell(cell.Data, cell.FormatInfo ? cell.FormatInfo : column);
            var elem = new Carina.LightGrid.CreateCell(cellObj);
            elem.setAttribute("id", cell.ColumnIndex.toString() + cell.RowIndex.toString());
            return elem;

        }
    }
}