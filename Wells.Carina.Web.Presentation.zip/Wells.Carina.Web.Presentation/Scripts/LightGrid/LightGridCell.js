"use strict";
{
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;

    Carina.LightGrid.LightGridCell = class extends Core.BaseControl
    {
        constructor(cellData)
        {
            super();
            this.Element = document.createElement("div");
            this.cellData = null;
            this.Element.setAttribute("id", cellData.Id);
            this.Height = cellData.Height;
           // this.Style("position", "absolute");
            this.Style("display", "inline-block");
           
        
        }

        Render(cellData, column)
        {
            //if (this.CompareCellData(this.cellData, cellData))
            //    return;

            this.cellData = cellData;

            if (cellData.FormatInfo)
            {
                cellData.FormatInfo.Top = cellData.Top;
                cellData.FormatInfo.Left = cellData.Left;
            }
            
            this.Attribute("id", cellData.ColumnIndex.toString() + cellData.RowIndex.toString());

            this.Style("top", cellData.Top );
            this.Style("left", cellData.Left);
            this.Element.Width = cellData.Width;
            this.Style("color", cellData.Foreground);
            this.Style("backgroundColor", cellData.Background);
            this.Style("font-family", cellData.FontFamily);
            this.Style("font-style", cellData.FontStyle);
            this.Style("font-weight", cellData.FontWeight);
            this.Style("visibility", cellData.Visible);
            this.Style("font-size", cellData.FontSize);
            this.Style("border", cellData.CellBorder + "px solid");
            this.Style("overflow", "hidden");
            this.Element.innerText = cellData.Data;
        }

        CompareCellData(cellData)
        {
            return this.cellData.Height == cellData.Height && this.cellData.Text == cellData.Text;
        }
    }
}