"use strict";
{
    // Namespace import
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;
    let Model = Carina.Model;

    Carina.LightGrid.LightGrid = class extends Core.BaseControl
    {
        constructor()
        {
            super();

            this.onScroll_Vertical_Handler = this.OnScroll_Vertical.bind(this);// Core.UiUtil.Debounce(this.OnScroll_Vertical, 50).bind(this);
            //this.onScroll_Vertical_Handler = Core.UiUtil.Throttle(this.OnScroll_Vertical).bind(this);
            this.dataContext_OnSpecChanged_Handler = this.DataContext_OnSpecChanged.bind(this);
            this.dataContext_OnSnapshotChanged_Handler = this.DataContext_OnSnapshotChanged.bind(this);

            this.Element = document.createElement("div");
            this.Element.setAttribute("name", "LightGrid");
            this.Element.setAttribute("offsetTop", 0);
            this.Element.style["overflow"] = "auto";

            this.header = new LightGrid.LightGridHeader(this);
            this.Element.appendChild(this.header.Element);

            this.panel = new LightGrid.LightGridPanel(this);
            this.Element.appendChild(this.panel.Element);

            this.contentTotal = new Core.DivControl();
            this.contentTotal.Attribute("name", "ContentTotal");
            this.Element.appendChild(this.contentTotal.Element);

            this.Element.addEventListener("scroll", this.onScroll_Vertical_Handler);

            // Should listen to resize event
            let size = Core.UiUtil.CalculateViewportResolution();
            this.Width = size.Width;
            this.Height = size.Height;
        }

        get Spec() { return this.spec; }
        get Id() { return this.spec.gridRunTimeId; }
        get Header() { return this.header; }

        OnDataContextChanged(oldValue, newValue)
        {
            if (oldValue)
            {
                oldValue.SpecChanged.Remove(this.dataContext_OnSpecChanged_Handler);
                oldValue.SnapshotChanged.Remove(this.dataContext_OnSnapshotChanged_Handler);
            }

            if (newValue)
            {
                newValue.SpecChanged.Add(this.dataContext_OnSpecChanged_Handler);
                newValue.SnapshotChanged.Add(this.dataContext_OnSnapshotChanged_Handler);
            }

            this.panel.DataContext = newValue;
        }

        DataContext_OnSpecChanged(specChangeArgs)
        {
            this.spec = specChangeArgs.NewValue;
            
            this.header.Reset();
            this.panel.Reset();

            this.horizontalViewport = null;
            this.verticalViewport = new Model.Viewport(10000, Math.floor(this.Height / this.Spec.RowHeight), 0);
            this.firstSnapshot = true;

            this.DataContext.Scroll(this.GetUpdateViewportRequest(true));
        }

        GetUpdateViewportRequest(vertical)
        {
            return { HorizontalViewport: (vertical ? null : this.horizontalViewport), VerticalViewport: (vertical ? this.verticalViewport : null) };
        }

        DataContext_OnSnapshotChanged(snapshot)
        {
            if (this.firstSnapshot)
            {
                this.firstSnapshot = false;

                this.contentTotal.Height = (this.spec.RowHeight * snapshot.VerticalViewport.Count) + this.spec.HeadersHeight;
                this.viewport = new Model.Viewport(10000, Math.round((this.Height - this.spec.HeadersHeight) / this.spec.RowHeight), 0);
            }

            this.header.Render(snapshot);
            this.panel.Render(snapshot);
            this.contentTotal.Width = this.header.Width;
        }

        OnScroll_Vertical(eventArgs)
        {
            let offset = Math.round(eventArgs.target.scrollTop / this.spec.RowHeight);

            this.verticalViewport = new Model.Viewport(10000, Math.round((this.Height - this.spec.HeadersHeight) / this.spec.RowHeight), offset);
            this.DataContext.Scroll(this.GetUpdateViewportRequest(true));
        }
    }
}