"use strict";
{
    // Namespace import
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;

    Carina.LightGrid.LightGrid = class extends Core.BaseControl
    {
        constructor()
        {
            super();

            this.onScroll_Vertical_Handler = this.OnScroll_Vertical.bind(this);
            this.dataContext_OnSpecChanged_Handler = this.DataContext_OnSpecChanged.bind(this);
            this.dataContext_OnSnapshotChanged_Handler = this.DataContext_OnSnapshotChanged.bind(this);

            this.Element = document.createElement("div");
            this.Element.setAttribute("name", "LightGrid");
            this.Element.setAttribute("offsetTop", 0);
            this.Element.style["overflow"] = "scroll";

            this.header = new LightGrid.LightGridHeader(this);
            this.Element.appendChild(this.header.Element);

            this.panel = new LightGrid.LightGridPanel(this);
            this.Element.appendChild(this.panel.Element);

            this.contentTotal = document.createElement("div");
            this.contentTotal.setAttribute("name", "ContentTotal");
            this.Element.appendChild(this.contentTotal);

            this.Element.addEventListener("scroll", this.onScroll_Vertical_Handler);
            this.size = Core.UiUtil.CalculateViewportResolution();
            this.isFirstRender = true;
        }

        get Spec() { return this.spec; }
        get Id() { return this.spec.gridRunTimeId; }
        get Size() { return this.size; }

        OnDataContextChanged(oldValue, newValue)
        {
            console.log(oldValue);
            if (oldValue)
            {
                oldValue.SpecChanged.Remove(this.dataContext_OnSpecChanged_Handler);
                oldValue.SnapshotChanged.Remove(this.dataContext_OnSnapshotChanged_Handler);
            }

            if (newValue)
            {
                newValue.SpecChanged.Add(this.dataContext_OnSpecChanged_Handler);
                newValue.SnapshotChanged.Add(this.dataContext_OnSnapshotChanged_Handler);
            }

            this.panel.DataContext = newValue;
        }

        DataContext_OnSpecChanged(specChangeArgs)
        {
            this.spec = specChangeArgs.NewValue;

            this.Element.style["width"] = this.size.Width + 30 + "px";
            this.Element.style["height"] = this.size.Height + 30 + "px";

            this.header.Reset();
            this.panel.Reset();

            this.contentTotal.style["height"] = (parseInt(this.spec.RowHeight) * parseInt(this.spec.TotalRowCount)).toString() + "px";
            this.isFirstRender = true;

            this.viewport = new Viewport(this.spec.TotalRowCount, Math.round(this.size.Height / this.spec.RowHeight), 0);
            this.spec["gridRowsSize"] = this.viewport.Size;

            this.DataContext.Scroll(this.viewport);
        }

        DataContext_OnSnapshotChanged(snapshot)
        {
            // console.log(snapshot);
            if (this.isFirstRender)
            {
                this.isFirstRender = false;
                this.header.Render(snapshot);
            }

            this.panel.Render(snapshot);
        }

        OnScroll_Vertical(eventArgs)
        {
            this.viewportScrollLeft = eventArgs.target.scrollLeft;
            this.viewportScrollTop = eventArgs.target.scrollTop;

            this.header.Element.style.top = this.viewportScrollTop + "px";
            this.panel.Element.style.top = this.viewportScrollTop + "px";

            let offset = Math.round(parseInt(this.viewportScrollTop) / parseInt(this.spec.RowHeight));
            this.viewport = new Viewport(this.spec.TotalRowCount, this.spec.gridRowsSize, offset);
            this.DataContext.Scroll(this.viewport);
        }
    }
}