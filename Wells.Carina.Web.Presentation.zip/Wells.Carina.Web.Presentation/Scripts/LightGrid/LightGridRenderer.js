﻿
function CalculateHeaderResolution(gridSpec, columnData)
{
    var sizes = {};
    var width = 0;
    for (var index = 0; index < columnData.length; index++)
    {
        width += parseInt(columnData[index].Width);
    }
    var height = parseInt(gridSpec.ColumnHeaderHeight);
    //added '10', purpose of height 
    sizes["width"] = width;
    sizes["height"] = height;
    return sizes;
}


function CreateCell(cell)
{
    var element = document.createElement("div");
    //debugger;
    if (element)
    {
        // console.log(cell.Top);
        element.setAttribute("id", cell.Id);
        element.style["width"] = cell.Width + "px";
        element.style["height"] = cell.Height + "px";
        element.style["color"] = cell.Foreground;
        element.style.backgroundColor = cell.Background;
        element.style["font-family"] = cell.FontFamily;
        element.style["font-size"] = cell.FontSize ? cell.FontSize + "px" : "initial";
        element.style["font-style"] = cell.FontStyle;
        element.style["font-weight"] = cell.FontWeight;
        element.style["visibility"] = cell.Visible;
        element.style["display"] = "inline-block";
        element.style["position"] = "absolute";
        element.style["top"] = cell.Top + "px";
        element.style["left"] = cell.Left + "px";
        element.style["border"] = cell.CellBorder + "px solid";
        element.style["overflow"] = "hidden";
        element.innerText = cell.Data;
    }
    return element;
}