﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;

    Carina.LightGrid.LightGridPanel = class extends Core.BaseControl
    {
        constructor(parent)
        {
            super();

            this.parent = parent;
            this.cells = [];
            this.isFirstRender = true;

            this.Element = document.createElement("div");
            this.Element.setAttribute("name", "LightGridPanel");
            this.Element.style["overflow"] = "hidden";
            this.Element.style["position"] = "relative";
        }

        Reset()
        {
            this.cells = [];
            this.isFirstRender = true;
            this.Element.style["height"] = (this.parent.Size.Height).toString() + "px";
        }

        Render(snapshot)
        {
            if (this.isFirstRender)
            {
                this.isFirstRender = false;
                
                let headerSize = CalculateHeaderResolution(this.parent.Spec, snapshot.Columns);

                this.Element.style["width"] = headerSize.width + "px";

                for (let i = 0; i < snapshot.Cells.length; i++)
                {
                    let cell = LightGridCellRenderer(snapshot.Cells[i], snapshot.Columns[snapshot.Cells[i].ColumnIndex]);
                    this.Element.appendChild(cell);
                    this.cells.push(cell);
                }
            }
            else
            {
                for (let i = 0, len = snapshot.Cells.length; i !== len; i++)
                {
                    this.cells[i].innerText = snapshot.Cells[i].Data;
                }
            }
        }
    }
}