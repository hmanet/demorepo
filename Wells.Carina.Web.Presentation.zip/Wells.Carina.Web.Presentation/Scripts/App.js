"use strict";
{
    // Namespace import
    let Server = Carina.Server;
    let Model = Carina.Model;
    let Vm = Carina.ViewModel;
    let View = Carina.View;

    Carina.App = class
    {
        constructor(serverUrl)
        {
            let connectionQs = { "gridRuntimeId": "12345" };
            let server = new Server.CarinaServer(serverUrl, "api/LightGridController/", "webLightGridHub", connectionQs);
            let source = new Model.TreeSource(server);

            this.GridComponentViewModel = new Vm.GridComponetViewModel(source);
            this.GridComponent = new View.GridComponent();
            this.GridComponent.DataContext = this.GridComponentViewModel;

            let mainDiv = document.getElementById("MainDiv");
            mainDiv.appendChild(this.GridComponent.Element);
        }
    }
}