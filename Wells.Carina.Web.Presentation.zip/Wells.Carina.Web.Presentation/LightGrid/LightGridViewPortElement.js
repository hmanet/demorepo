﻿"use strict";
class LightGridViewPortElement
{
    constructor()
    {
    }
    Renderer(obj)
    {
        var viewportSize = CalculateViewportResolution();
        var viewportObj = new GridRenderer(viewportSize.Width, viewportSize.Height, obj.gridComponentSpecData.gridRunTimeId, 0, 0);
        var viewport = CreateViewport(viewportObj, obj);
        var header = document.createElement("div");
        header.setAttribute("id", obj.gridComponentSpecData.GridRunTimeId + "_header")
        header.style["height"] = (obj.gridComponentSpecData.ColumnHeaderHeight).toString() + "px";
        header.style["overflow"] = "hidden";
        header.style["position"] = "relative";
        var viewportContentElement = document.createElement("div");
        viewportContentElement.setAttribute("id", obj.gridComponentSpecData.GridRunTimeId + "_viewportContentElement")
        viewportContentElement.style["height"] = (viewportObj.Height).toString() + "px";
        viewportContentElement.style["overflow"] = "hidden";
        viewportContentElement.style["position"] = "relative";
        var viewportContentTotalElement = document.createElement("div");
        viewportContentTotalElement.setAttribute("id", obj.gridComponentSpecData.GridRunTimeId + "_viewportContentTotalElement")
        viewportContentTotalElement.style["height"] = (parseInt(obj.gridComponentSpecData.RowHeight) * parseInt(obj.gridComponentSpecData.TotalRowCount)).toString() + "px";
        viewport.appendChild(header);
        viewport.appendChild(viewportContentElement);
        viewport.appendChild(viewportContentTotalElement);
        return viewport;

    }
}