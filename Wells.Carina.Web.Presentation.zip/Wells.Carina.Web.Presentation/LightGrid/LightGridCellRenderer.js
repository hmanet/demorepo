function LightGridCellRenderer(cell)
{
    var elem = document.createElement("div");
    if (elem)
    {
        elem.setAttribute("id", cell.Id);
        elem.style["width"] = cell.Width + "px";
        elem.style["height"] = cell.Height + "px";
        elem.style["color"] = cell.Color ? cell.Color : "#a4a4a4";
        elem.style["background"] = cell.Background ? cell.Background : "#343434";
        elem.style["text-align"] = cell.TextAlign ? cell.TextAlign : "left";
        elem.style["display"] = "inline-block";
        elem.style["border"] = "0.5px solid ";
        elem.style["overflow"] = "hidden";
        elem.innerText = cell.Data;
    }
    return elem;
}