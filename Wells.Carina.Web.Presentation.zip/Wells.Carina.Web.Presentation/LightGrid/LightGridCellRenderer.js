"use strict";
function LightGridCellRenderer(cell, column) {
    column.Top=cell.Top;
    column.Left = cell.Left;
    if (cell.FormatInfo)
    {
        cell.FormatInfo.Top = cell.Top;
        cell.FormatInfo.Left = cell.Left;
    }
    var cellObj = new LightGridCell(cell.Data, cell.FormatInfo ? cell.FormatInfo : column);
    var elem = CreateCell(cellObj);
    elem.setAttribute("id", cell.ColumnIndex.toString() + cell.RowIndex.toString());
    return elem;
}