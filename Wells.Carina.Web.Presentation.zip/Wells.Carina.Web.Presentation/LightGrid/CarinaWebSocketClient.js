"use strict";
class CarinaWebSocketClient
{
    constructor(connectionUri)
    {
        this.ConnectionUri = connectionUri + "signalr";
        this.signalrConnection = $.hubConnection(this.ConnectionUri, {
            useDefaultPath: false
        });

        this.CarinaWebSocketProxy = this.signalrConnection.createHubProxy('webLightGridHub');

        this.CarinaWebSocketProxy.connection.qs = { 'gridRuntimeId': '1234' };

        this.CarinaWebSocketProxy.on("receiveSnapShot");      
      
        this.ReceivedEvent = new SignalRKeyedEvent(this.CarinaWebSocketProxy);       
       
    }

    Connect(handler)
    {
    
       this.signalrConnection.start({ waitForPageLoad: false }).done(function ()
        {

            //alert("Connected to Signalr Server11");
           handler();

        })
      .fail(function (error)
      {
          //alert("failed in connecting to the signalr server");
      })

      
    }
   
    Send(key, value)
    {
        if (value == undefined)
        {
            this.CarinaWebSocketProxy.invoke(key);
        }
        else
        {
            this.CarinaWebSocketProxy.invoke(key,value);
        }
    };

}

class SignalRKeyedEvent
{
    constructor(webSocketProxy)
    {
        this.WebSocketProxy = webSocketProxy;
    }


    Register(receiver,handler)
    {
        this.WebSocketProxy.on(receiver,handler);
    }

    UnRegister(receiver, handler)
    {
        
    }
}

//remove this 
class SignalRActions {
    constructor(webSocketProxy) {
        this.WebSocketProxy = webSocketProxy;

    }

  
}
