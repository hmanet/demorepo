"use strict";
class Main
{
    constructor()
    {
        var serverUrl = "http://localhost:9000/";
        var carinaWebSocketServerUrl = serverUrl + "signalr";
             
        this.webSocketClient = new CarinaWebSocketClient(carinaWebSocketServerUrl);
        this.server = new CarinaServer("http://localhost:9000/api/LightGridController/",this.webSocketClient );        
        this.webSocketClient.Connect(this.OnConnectionEstablished.bind(this));
    }

    OnConnectionEstablished()
        {
            this.component = new GridComponent(this.server,this.webSocketClient);
        };
};
