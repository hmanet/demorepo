"use strict";
class LightGrid {
    constructor(server, webSocketClient)
     {
        this.server = server;
        this.snapShot;
        this.viewportElement;
        this.viewporRenderer;
        this.viewport = new Viewport();
        this.webSocketClient = webSocketClient;
    }
   
    ViewportSet(value, spec) {
        this.viewport = value;
        this.gridComponentSpecData = spec;
        this.gridComponentSpecData["gridRowsSize"] = value.Size;
        LightGridViewPortElement=new LightGridViewPortElement();
        this.viewportElement=LightGridViewPortElement.Renderer(this);
        this.viewporRenderer=new LightGridViewPortRenderer(this);
        if (this.viewportElement) {
            WindowOnLoad(this.viewportElement);
        }
        var Parent = this;
         this.webSocketClient.ReceivedEvent.Register("recieveSnapShot", this.OnSnapshotReceived.bind(this));
         this.webSocketClient.Send("getSnapShot", { "name": "getSnapShot", "viewPort": { "count": this.viewport.Count, "size": this.viewport.Size, "offset": this.viewport.Offset } });
    }

    OnSnapshotReceived(value) {
        this.viewporRenderer.Renderer(value,this);
    };
};

function WindowOnLoad(gridElement) {
    document.getElementById("GridComp").appendChild(gridElement);
}
function OnViewportScroll(object) {
    var e = object.domTarget;
    var obj = object.obj;
    this.viewportScrollLeft = e.target.scrollLeft;
    this.viewportScrollTop = e.target.scrollTop;
    e.target.childNodes[0].style.top = this.viewportScrollTop + "px";
    e.target.childNodes[1].style.top = this.viewportScrollTop + "px";
    if ((e.target.childNodes[2].clientHeight - e.target.scrollTop) < 0) {
        return false;
    }
    var offset = Math.round(parseInt(this.viewportScrollTop) / parseInt(e.target.childNodes[1].childNodes[0].clientHeight));
    var viewport = new Viewport(obj.gridComponentSpecData.TotalRowCount, obj.gridComponentSpecData.gridRowsSize, offset)
    OnClientSendInfo(viewport, e.target.childNodes[1],obj);
}

var OnClientSendInfo = _.debounce(function (viewport, element, obj) {
    this.viewPortArea = element;
    var Parent = this;
    obj.webSocketClient.Send("getSnapShot", { "name": "getSnapShot", "viewPort": { "count": viewport.Count, "size": viewport.Size, "offset": viewport.Offset } });

}, 0);

