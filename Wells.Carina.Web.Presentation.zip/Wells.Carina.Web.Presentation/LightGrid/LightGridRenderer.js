﻿"use strict";
function CalculateViewportResolution()
{     
    var width = Math.round((window.innerWidth) * (0.6));
    var height = Math.round((window.innerHeight) *0.5);
    var sizes = new Size(width, height);
    return sizes;
    
}

//function to create viewport 
function CreateViewport(viewportObj, obj) {
    var element = document.createElement("div");
    element.setAttribute("id", viewportObj.Id);
    element.setAttribute("offsetTop", viewportObj.OffsetTop ? viewportObj.OffsetTop : 0);
    element.style["width"] = parseInt(viewportObj.Width) + 30 + "px";
    element.style["height"] = viewportObj.Height + 30 + "px";
    element.style["overflow"] = "scroll";
    obj.server.ReceivedEvent.Add("OnScroll", OnViewportScroll);
    element.addEventListener("scroll", function ($event)
    {
       obj.server.ReceivedEvent.Invoke("OnScroll", { "domTarget": $event, "obj": obj });
    });
    return element;
    
}

function CalculateHeaderResolution(gridSpec, columnData)
{
    var sizes = {};
    var width = 0;
    for (var index = 0; index < columnData.length; index++)
    {
        width += parseInt(columnData[index].Width);
    }
    var height = parseInt(gridSpec.ColumnHeaderHeight);
    //added '10', purpose of height 
    sizes["width"] = width;
    sizes["height"] = height;
    return sizes;
     
}


function CreateCell(cell)
{
    var element = document.createElement("div");
    //debugger;
    if (element)
    {
      // console.log(cell.Top);
        element.setAttribute("id", cell.Id);
        element.style["width"] = cell.Width + "px";
        element.style["height"] = cell.Height + "px";
        element.style["color"] = cell.Foreground ;
        element.style.backgroundColor = cell.Background ;
        element.style["font-family"] = cell.FontFamily ;
        element.style["font-size"] = cell.FontSize ? cell.FontSize + "px" : "initial";
        element.style["font-style"] = cell.FontStyle ;
        element.style["font-weight"] = cell.FontWeight;     
        element.style["visibility"] = cell.Visible ;
        element.style["display"] = "inline-block";
        element.style["position"] = "absolute";
        element.style["top"] = cell.Top+"px";
        element.style["left"] =cell.Left+"px";
        element.style["border"] = cell.CellBorder+"px solid";
        element.style["overflow"] = "hidden";
        element.innerText = cell.Data;
    }
    return element;


}