"use strict";
class LightGridViewPortRenderer
{
    constructor(obj)
    {
        this.isIntialized = true;
        this.template = obj.viewportElement;
        this.tempdata;
    }
    Renderer(snapshot, obj)
    {
        var model = new LightGridViewportModel(snapshot);
        if (this.isIntialized)
        {
            this.isIntialized = false;
            this.tempdata = model;
            this.template.setAttribute("name", "viewport");
            var header = document.getElementById(obj.gridComponentSpecData.GridRunTimeId + '_header');
            var headerSize = CalculateHeaderResolution(obj.gridComponentSpecData, model.Columns);
            header.style["width"] = headerSize.width + "px";
            var viewportContentElement = document.getElementById(obj.gridComponentSpecData.GridRunTimeId + '_viewportContentElement');
            viewportContentElement.style["width"] = headerSize.width + "px";
            var headerElements = [];
            var headerLeft = 0, count = 0;
            for (var index = 0; index < model.Columns.length; index++)
            {
                var cellData = model.Columns[index];
                cellData["Height"] = obj.gridComponentSpecData.ColumnHeaderHeight;
                cellData["Top"] = "0px";
                if (index)
                {
                    headerLeft += model.Columns[index - 1].Width;
                }
                cellData["Left"] = headerLeft;
                count += 1;
                var cell = new LightGridColumn(cellData);
                var element = CreateCell(cell);
                headerElements.push(element);
            }
            if (headerElements.length)
            {
                for (var index = 0; index < headerElements.length; index++)
                {
                    header.appendChild(headerElements[index]);
                }
            }
            for (var i = 0; i < model.Cells.length; i++)
            {
                var cell = LightGridCellRenderer(model.Cells[i], model.Columns[model.Cells[i].ColumnIndex]);
                viewportContentElement.appendChild(cell);
            }
        }
        else
        {
            var equal = JSON.stringify(this.tempdata) === JSON.stringify(model);
            if (equal)
            {
                //console.log("json is equal")
            }
            else
            {
               // console.log("json is not equal");
                var viewportContentElement = document.getElementById(obj.gridComponentSpecData.GridRunTimeId + '_viewportContentElement');
                for (var i = 0; i < model.Cells.length; i++)
                {
                    var elem = viewportContentElement.children[i].innerText = model.Cells[i].Data;
                   // console.log(elem.id)
                }
            }

        }
    }
}

