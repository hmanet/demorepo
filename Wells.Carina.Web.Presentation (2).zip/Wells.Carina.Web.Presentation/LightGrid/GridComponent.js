class GridComponent {
    constructor(server, webSocketClient)
     {
        this.server = server;
        this.webSocketClient = webSocketClient;
        this.Grid = new LightGrid(this.server, this.webSocketClient);
        this.spec = new GridComponentSpec();
        server.ReceivedEvent.Add("GetGridComponentSpec", this.OnGridComponentSpecReceived.bind(this));
        server.Send("GetGridComponentSpec");
    };
    OnGridComponentSpecReceived(spec) 
    {
        this.spec = spec;
        var size = CalculateViewportResolution();
        var viewport = new Viewport(spec.TotalRowCount, Math.round(size.Height / spec.RowHeight), 0);
        this.Grid.ViewportSet(viewport, spec);
    };
};