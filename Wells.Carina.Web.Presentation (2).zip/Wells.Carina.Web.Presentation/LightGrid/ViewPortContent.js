function ViewportContent(id, width, height, offsetleft, offsettop, background, textalign, display) 
{
    this.Id = id || 0;
    this.Width = width;
    this.Height = height;
    this.OffsetLeft = offsetleft ? offsetleft : 0;
    this.OffsetTop = offsettop ? offsettop : 0;
    this.Background = background ? background : "#fff";
    this.TextAlign = textalign ? textalign : "left";
    this.Display = display ? display : "block";
}