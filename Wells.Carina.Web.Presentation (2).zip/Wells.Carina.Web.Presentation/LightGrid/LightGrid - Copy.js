class LightGrid
{
    constructor(server, webSocketClient)
     {
        this.server = server;
        this.snapShot;
        this.viewport = new Viewport();
        this.webSocketClient = webSocketClient;
     }

    GetRowSize()
    {
        var viewportSize = CalculateViewportResolution();
        var rowssize = Math.round(viewportSize.Height / this.gridComponentSpecData.rowHeight);
        return rowssize;
    };

    ViewportGet() 
    {
        return this.viewport;
    }
    ViewportSet(value, spec)
    {
        this.viewport = value;
        this.gridComponentSpecData = spec;
        var rowssize = this.GetRowSize();
        var Parent = this;
         this.webSocketClient.ReceivedEvent.Register("recieveSnapShot", this.OnSnapshotReceived.bind(this));
         this.webSocketClient.ReceivedEvent.Register("recieveUpdateSnapShot", this.UpdateContent.bind(this));
         this.webSocketClient.Send("getSnapShot", { "name": "getSnapShot", "viewPort": { "count": 0, "size": rowssize, "offset": 0 } });
    }

    OnSnapshotReceived(value)
    {
        this.OnInitialize(value);
    };

    UpdateRow(length, data, element)
    {
        for (var index = 0; index < length; index++) 
        {
            if (data[index].data) {
                element.childNodes[index].innerText = data[index].data;
            } else {
                element.childNodes[index].innerText = "";
            }
        }
    };

    UpdateContent(updateData) 
    {
        var viewportArea= this.viewportContentElement;
        var viewportRowsData = [];
        var viewportSize = CalculateViewportResolution();
        //console.log("updateevent");
        var rowssize = this.GetRowSize();;
        var snapShot = updateData;
         for (var index = 0; index < rowssize; index++) 
         {
            var rowIndex = index * snapShot.columnSpecs.length;
            var rowData = [];
            for (var cellIndex = rowIndex; cellIndex < snapShot.columnSpecs.length * (index + 1); cellIndex++)
            {
                rowData.push(snapShot.cells[cellIndex]);
            }
            viewportRowsData.push(rowData)
            
        }
        var viewportContentRows = [];
        if (viewportRowsData.length) 
        {
            for (var index = 0; index < viewportRowsData.length; index++)
            {
                this.UpdateRow(viewportArea.childNodes[index].childNodes.length, viewportRowsData[index], viewportArea.childNodes[index]);
            }
        }

    };


    OnInitialize(value)
    {debugger;
        //console.log("onintializess")
        this.snapShot = value;
        if (this.gridComponentSpecData) 
        {
            if (this.snapShot) {
                var viewportSize = CalculateViewportResolution();
                var viewportObj = new GridRenderer(viewportSize.Width, viewportSize.Height, this.gridComponentSpecData.gridRunTimeId, 0, 0);
                var viewport = CreateViewport(viewportObj, this);
                var headerSize = CalculateHeaderResolution(this.gridComponentSpecData, this.snapShot.columnSpecs)
                var headerObj = new LightGridHeader("LGH1", "", headerSize.width, headerSize.height);
                var header = LightGridColumnRenderer(viewport, headerObj);
                var viewportTotalContentSizes = CalculateViewportContentResolution(this.gridComponentSpecData, this.snapShot.columnSpecs);
                var viewportContentTotalObj = new ViewportContent("gridContent1", viewportTotalContentSizes.width, viewportTotalContentSizes.height)
                var viewportContentTotalElement = LightGridCreateTotalContent(viewportContentTotalObj);
                var ViewPortContentObj = new ViewportContent("LGVCD1", viewportTotalContentSizes.width, viewportObj.Height - this.gridComponentSpecData.columnHeaderHeight);
                var viewportContentElement = LightGridCreateContent(ViewPortContentObj);
                //Client Calculation of RowSize 
                var rowssize = this.GetRowSize();;
                this.gridComponentSpecData["gridRowsSize"] = rowssize;
                var headerElements = []
                for (var index = 0; index < this.snapShot.columnSpecs.length; index++) 
                {
                    var cellData = this.snapShot.columnSpecs[index];
                    var cell = new LightGridColumn(cellData);
                    var element = CreateCell(cell)
                    headerElements.push(element);
                }

                if (headerElements.length)
                {
                    for (var index = 0; index < headerElements.length; index++)
                    {
                        header.appendChild(headerElements[index]);
                    }
                    viewport.appendChild(header);
                }

                var viewportRowsData = [];
              
                for (var index = 0; index < this.gridComponentSpecData.gridRowsSize; index++)
                {
                    var rowIndex = index * this.snapShot.columnSpecs.length;
                    var rowData = [];
                    for (var cellIndex = rowIndex; cellIndex < this.snapShot.columnSpecs.length * (index + 1); cellIndex++)
                    {
                        rowData.push(this.snapShot.cells[cellIndex]);
                    }
                    viewportRowsData.push(rowData)
                }
                var viewportContentRows = [];
                if (viewportRowsData.length) {
                    for (var index = 0; index < viewportRowsData.length; index++)
                    {
                        var element = CreateRow(index, this.snapShot.columnSpecs.length, viewportRowsData[index], this.snapShot.columnSpecs);
                        viewportContentRows.push(element);
                    }
                }
                if (viewportContentRows.length) {
                    for (var index = 0; index < viewportContentRows.length; index++) 
                    {
                        viewportContentElement.appendChild(viewportContentRows[index])
                    }
                    viewport.appendChild(viewportContentElement);
                    viewport.appendChild(viewportContentTotalElement);
                    this.viewportContentElement = viewportContentElement;
                }
            }
        }

        if (viewport) 
        {
            WindowOnLoad(viewport);
        }
    }

};
function WindowOnLoad(gridElement)
{
    document.getElementById("GridComp").appendChild(gridElement);
}
function OnViewportScroll(object)
{
    var e = object.domTarget;
    var obj = object.obj;
    this.viewportScrollLeft = e.target.scrollLeft;
    this.viewportScrollTop = e.target.scrollTop;
    e.target.childNodes[0].style.top = this.viewportScrollTop + "px";
    e.target.childNodes[1].style.top = this.viewportScrollTop + "px";
    if ((e.target.childNodes[2].clientHeight - e.target.scrollTop) < 0)
    {
        return false;
    }
    var offset = Math.round(parseInt(this.viewportScrollTop) / parseInt(e.target.childNodes[1].childNodes[0].clientHeight));
    var viewport = new Viewport(obj.gridComponentSpecData.totalRowCount, obj.gridComponentSpecData.gridRowsSize, offset)
    OnClientSendInfo(viewport, obj);
}

OnClientSendInfo = _.debounce(function (viewport, obj)
{
      
    var Parent = this;  
    obj.webSocketClient.Send("getUpdateSnapShot",{ "name": "getUpdateSnapShot", "viewPort": { "count": viewport.Count, "size": viewport.Size, "offset": viewport.Offset  } });
    
}, 0);

