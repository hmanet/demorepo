function FormatInfo(editable,foreground, background,fontFamily,fontWeight,fontStyle,fontSize,visible,strikethrough,underline)
{
    this.Editable = editable;
    this.Foreground = foreground;
    this.Background = background;
    this.FontFamily = fontFamily;
    this.FontWeight = fontWeight;
    this.FontStyle = fontStyle;
    this.FontSize = fontSize;
    this.Visible = visible;
    this.Strikethrough = strikethrough;
    this.Underline = underline;   
    
};