function LightGridCell(cellData,data)
 {
      var styleInfo=data.FormatInfo;
      this.Data =cellData ;
      this.Height=data.Height;
      this.Width=data.Width;
      this.Background =styleInfo.Background;
      this.Editable =styleInfo.Editable;
      this.FontFamily=styleInfo.FontFamily;
      this.FontStyle=styleInfo.FontStyle;
      this.FontSize=styleInfo.FontSize;
      this.FontWeight=styleInfo.FontWeight;
      this.Foreground=styleInfo.Foreground;
      this.TextUnderline=styleInfo.Underline;
      this.TextStrikethrough=styleInfo.Strikethrough;
      this.Visible=styleInfo.Visible;
  
  }  