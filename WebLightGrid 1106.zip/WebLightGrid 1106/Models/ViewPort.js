function Viewport(count,size,offset){
    this.Count=count;
    this.Size=size;
    this.Offset=offset;
}
function GridRenderer(width, height, id, horizontalViewport, verticalViewport)
{
    this.Width = width;
    this.Height = height;
    this.Id = id;
    this.HorizontalViewport =horizontalViewport;
    this.VerticalViewport =verticalViewport;
}
function LightGridAjaxParams(method,url,contentType,Data) 
{
    this.Method;
    this.Url;
    this.ContentType;
    this.Data;
}





