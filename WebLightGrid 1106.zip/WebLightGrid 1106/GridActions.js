function WindowOnLoad() {
    document.getElementById("GridComp").appendChild(gridElement);
}
function OnViewportScroll(object) {
    var e = object.domTarget;
    var obj = object.obj;
    this.viewportScrollLeft = e.target.scrollLeft;
    this.viewportScrollTop = e.target.scrollTop;
    e.target.childNodes[0].style.top = this.viewportScrollTop + "px";
    e.target.childNodes[1].style.top = this.viewportScrollTop + "px";
    if ((e.target.childNodes[2].clientHeight - e.target.scrollTop) < 0) {
        return false;
    }
    var offset = Math.round(parseInt(this.viewportScrollTop) / parseInt(e.target.childNodes[1].childNodes[0].clientHeight));
    var viewport = new Viewport(obj.gridComponentSpecData.totalRowCount, obj.gridComponentSpecData.gridRowsSize, offset)
    OnClientSendInfo(viewport, e.target.childNodes[1], obj);
}

OnClientSendInfo = _.debounce(function (viewport, element, obj) {
    var data = {
        "element": element,
        "viewport": viewport,
    }
    obj.server.Send("GetSnapshot", data.viewport).then(
        data => {
            this.snapShot = data;
            obj.server.ReceivedEvent.Invoke("OnUpdate", { "data": data, "element": element, "obj": obj });
        },
        error => { });

}, 1);

function UpdateContent(updateData) {
    var viewportRowsData = [];
    var gridComponentSpecData = updateData.obj.gridComponentSpecData;
    var snapShot = updateData.data;

    for (var index = 0; index < gridComponentSpecData.gridRowsSize; index++) {
        rowIndex = index * snapShot.columnsDescription.length;
        var rowData = [];
        for (var cellIndex = rowIndex; cellIndex < snapShot.columnsDescription.length * (index + 1); cellIndex++) {
            rowData.push(snapShot.cells[cellIndex]);
        }
        viewportRowsData.push(rowData)
        console.log(viewportRowsData)
    }
    var viewportContentRows = [];
    if (viewportRowsData.length) {
        for (var index = 0; index < viewportRowsData.length; index++) {
            UpdateRow(updateData.element.childNodes[index].childNodes.length, viewportRowsData[index], updateData.element.childNodes[index]);
        }
    }

}
function UpdateRow(length, data, element) {
    for (var index = 0; index < length; index++) {
        if (data[index].data) {
            element.childNodes[index].innerText = data[index].data;
        } else {
            element.childNodes[index].innerText = "";
        }
    }
}

function LightGridCreateContent(viewportContentObj) {
    var element = document.createElement("div")
    element.setAttribute("id", viewportContentObj.Id);
    element.setAttribute("offsetLeft", viewportContentObj.OffsetLeft ? viewportContentObj.OffsetLeft : 0);
    element.setAttribute("offsetTop", viewportContentObj.OffsetTop ? viewportContentObj.OffsetTop : 0);
    element.style["width"] = parseInt(viewportContentObj.Width) + 30 + "px";
    element.style["height"] = viewportContentObj.Height + "px";
    element.style["position"] = "relative";
    element.style["top"] = "0px";
    return element;
}

function LightGridCreateTotalContent(contentobj) {
    var element = document.createElement("div");
    element.setAttribute("id", contentobj.Id);
    element.setAttribute("offsetLeft", contentobj.OffsetLeft ? contentobj.OffsetLeft : 0);
    element.setAttribute("offsetTop", contentobj.OffsetTop ? contentobj.OffsetTop : 0);
    element.style["width"] = contentobj.Width + "px";
    element.style["height"] = contentobj.Height + "px";
    element.style["display"] = "inline-block";
    return element;
}

function LightGridCreateContent(viewportContentObj) {
    var element = document.createElement("div")
    element.setAttribute("id", viewportContentObj.Id);
    element.setAttribute("offsetLeft", viewportContentObj.OffsetLeft ? viewportContentObj.OffsetLeft : 0);
    element.setAttribute("offsetTop", viewportContentObj.OffsetTop ? viewportContentObj.OffsetTop : 0);
    element.style["width"] = parseInt(viewportContentObj.Width) + 30 + "px";
    element.style["height"] = viewportContentObj.Height + "px";
    element.style["position"] = "relative";
    element.style["top"] = "0px";
    return element;
}

function LightGridCreateTotalContent(contentobj) {
    var element = document.createElement("div");
    element.setAttribute("id", contentobj.Id);
    element.setAttribute("offsetLeft", contentobj.OffsetLeft ? contentobj.OffsetLeft : 0);
    element.setAttribute("offsetTop", contentobj.OffsetTop ? contentobj.OffsetTop : 0);
    element.style["width"] = contentobj.Width + "px";
    element.style["height"] = contentobj.Height + "px";
    element.style["display"] = "inline-block";
    return element;
}
function CreateRow(rowIndex, length, data, styledata) {
    console.log(data);
    var element = document.createElement("div");
    for (var index = 0; index < length; index++) {
        // var subElement = document.createElement("div");
        var cellObj = new LightGridCell(data[index].data,data[index].formatInfo?data[index].formatInfo:styledata[index]); 
        var subElement = CreateCell(cellObj) ;
        // subElement.innerHTML = cellObj.Data;
        // subElement.style.width = cellObj.Width + "px";
        // subElement.style.height = cellObj.Height + "px";
        // subElement.style["background"] = cellObj.Background ? cellObj.Background : "#343434";
        // subElement.style["display"] = "inline-block";
        // subElement.style["border"] = "0.5px solid";
        // subElement.style["overflow"] = "hidden"
        element.appendChild(subElement);
    }
    element.style.height = styledata[0].height + "px";
    return element;
}

//function to create viewport 
function CreateViewport(viewportObj, obj) {
    var element = document.createElement("div")
    element.setAttribute("id", viewportObj.Id);
    element.setAttribute("offsetTop", viewportObj.OffsetTop ? viewportObj.OffsetTop : 0);
    element.style["width"] = parseInt(viewportObj.Width) + 30 + "px";
    element.style["height"] = viewportObj.Height + 30 + "px";
    element.style["overflow"] = "scroll";
    obj.server.ReceivedEvent.Add("OnScroll", OnViewportScroll);
    // obj.server.ReceivedEvent.Add("OnIntialSend", obj.GetSnapshot);
    obj.server.ReceivedEvent.Add("OnUpdate", UpdateContent);
    element.addEventListener("scroll", function ($event) {
        obj.server.ReceivedEvent.Invoke("OnScroll", { "domTarget": $event, "obj": obj });
    });
    return element;
}

function CalculateHeaderResolution(intialData, columnData) {
    var sizes = {};
    var width = 0;
    for (var index = 0; index < columnData.length; index++) {
        width += parseInt(columnData[index].width);
    }
    var height = parseInt(intialData.columnHeaderHeight);
    //added '10', purpose of height 
    sizes["width"] = width;
    sizes["height"] = height;
    return sizes;
}


function CalculateViewportContentResolution(intialdata, columndata) {
    var sizes = {};
    var width = 0;
    for (var index = 0; index < columndata.length; index++) {
        width += parseInt(columndata[index].width);
    }
    // width=Math.round((window.width)*(50/100));
    var height = parseInt(intialdata.totalRowCount) * parseInt(intialdata.rowHeight);
    // var height = Math.round((window.height)*(50/100))

    sizes["width"] = width;
    sizes["height"] = height;
    return sizes;
}

function CreateCell(cell) {
    var element = document.createElement("div");
    if (element) {
        // element.setAttribute("id", cell.Id);
        // element.style["width"] = cell.Width + "px";
        // element.style["height"] = cell.Height + "px";
        // element.style["color"] = cell.Color ? cell.Color : "#a4a4a4";
        // element.style["background"] = cell.Background ? cell.Background : "#343434";
        // element.style["text-align"] = cell.TextAlign ? cell.TextAlign : "left";
        // element.style["display"] = "inline-block";
        // element.style["border"] = "0.5px solid ";
        // element.style["overflow"] = "hidden";
        // element.innerText = cell.Data;
        element.setAttribute("id",cell.Id);
        element.style["width"]=cell.Width+"px";
        element.style["height"]=cell.Height+"px";
        element.style["color"]=cell.Foreground?cell.Foreground:"#a4a4a4";
        element.style["background"]=cell.Background?cell.Background:"#343434";
        element.style["text-align"]=cell.TextAlign?cell.TextAlign:"left";
        element.style["text-decoration-line"]=cell.TextUnderline?"underline":"none";
        element.style["text-decoration-line"]=cell.TextStrikethrough?"line-through":"none";
        element.style["font-family"]=cell.FontFamily?cell.FontFamily:"initial";
        element.style["font-size"]=cell.FontSize?cell.FontSize+"px":"initial";
        element.style["font-style"]=cell.FontStyle?cell.FontStyle:"initial";
        element.style["font-weight"]=cell.FontWeight?cell.FontWeight:"initial";
        element.style["border"]=(cell.cellBorder?cell.cellBorder:"0.5")+"px solid";
        element.style["visibility"]=cell.Visible?"visible":"hidden";
        element.style["display"]="inline-block";
        element.style["border"]="0.5px solid ";
        element.style["overflow"]="hidden";
        element.innerText=cell.Data;
    }
    return element;
}

function CalculateViewportResolution(intialData, columnData) {
    var sizes = {};
    var width = 0;
    width = Math.round((window.innerWidth) * (50 / 100));

    var height = Math.round((window.innerHeight) * (0.25))
    //added '30', purpose of height compatabulity.
    sizes["width"] = width;
    sizes["height"] = height;
    return sizes;
}
function GetUpdateSnapshot() {
    UpdateContent(this.snapShot.cells, element);
}
