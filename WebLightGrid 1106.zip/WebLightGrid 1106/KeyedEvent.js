function KeyedEvent()
{
    this.handlers = {};

    this.Add = function (key, handler)
    {
        if (this.handlers[key] == null) this.handlers[key] = new Array();
        this.handlers[key]=(handler);
    }
    this.Remove = function (key, handler) 
    {
        //TODO: the oposite
    }

    // this.Invoke = function (key, value)
    // {
    //     let h = handlers[key];
    //     if (h == undefined) return;
    //     for (let i = 0; i < h.length; ++i) h[i](value);
    // }
    this.Invoke = function (key, value) 
    {
        var scope = value || window;
        if (this.handlers[key])
        {
            this.handlers[key](value);
        }
    }
}
