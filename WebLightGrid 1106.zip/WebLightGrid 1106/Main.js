//global Varaibles
var gridComponentSpecData;//TODO: move to component
var snapShot;//TODO: move to grid
//only initialization in main 
class Main
{
    //this.server = new MockGridComponentServer();
    constructor(){
        this.server = new CarinaServer("http://localhost:8080/api/LightGridController/");
        this.component = new GridComponent(this.server);
    }
    
};
