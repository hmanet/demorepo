class GridComponent
{
    // function ctor(obj)
    // {
    //     obj.server.ReceivedEvent.Add("GetGridComponentSpec", obj.OnGridComponentSpecReceived);
    //     obj.server.Send("GetGridComponentSpec");
    // };
    constructor(server){
        debugger
        this.server = server;
        this.Grid = new LightGrid(server);
        server.ReceivedEvent.Add("GetGridComponentSpec", this.OnGridComponentSpecReceived);
        server.Send("GetGridComponentSpec")
        .then(
            data=>{
                this.OnGridComponentSpecReceived(data);
        },
        error=>{

        }
    );
    }
    OnGridComponentSpecReceived(spec)
    {
        var size=CalculateViewportResolution();
        var viewport = new Viewport(spec.totalRowCount,Math.round(size.height/spec.rowHeight) , 0);
        
        this.Grid.Viewport(viewport,spec);
    };
};
