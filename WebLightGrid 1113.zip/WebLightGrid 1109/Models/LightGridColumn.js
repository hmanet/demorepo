function LightGridColumn(data)
 {
    // this.Id = id || 0;
    // this.Data = data;
    // this.Width = width;
    // this.Height = height;
    // this.OffsetLeft = offsetleft ? offsetleft : 0;
    // this.OffsetTop = offsettop ? offsettop : 0;
    // this.Background = background ? background : "#343434";
    // this.TextAlign = textalign ? textalign : "left";
    // this.Display = display ? display : "inline-block";
    var styleInfo=data.formatInfo;
    this.Data = data.colName;
    this.Height=data.height;
    this.Width=data.width;
    this.Background =styleInfo.background;
    this.BackgroundBlendMode =styleInfo.blendBackground;
    this.cellBorder =styleInfo.cellBorder;
    this.Editable =styleInfo.editable;
    this.FontFamily=styleInfo.fontFamily;
    this.FontStyle=styleInfo.FontStyle;
    this.FontSize=styleInfo.fontSize;
    this.FontWeight=styleInfo.FontWeight;
    this.Foreground=styleInfo.foreground;
    this.RowBorder=styleInfo.rowBorder;
    this.TextUnderline=styleInfo.underline;
    this.TextStrikethrough=styleInfo.strikethrough;
    this.Visible=styleInfo.visible;
}
function LightGridHeader(id,data,width,height,background,offsetleft,offsettop,textalign,display){
    this.Id = id || 0;
    this.Data = data;
    this.Width = width;
    this.Height = height;
    this.OffsetLeft = offsetleft ? offsetleft : 0;
    this.OffsetTop = offsettop ? offsettop : 0;
    this.Background = background ? background : "#343434";
    this.TextAlign = textalign ? textalign : "left";
   // this.Display = display ? display : "inline-block";
    
}

/*function LightGridCreateHeaderCells(elme, ColumnData) {
    for (var index = 0; index < ColumnData.length; index++) {
        var Eelement = createElement("div");
        Element.setAttribute("Id", ColumnData[index].id)

    }
} */