class CarinaWebSocketClient
{
    constructor(connectionUri)
    {
        this.ConnectionUri = connectionUri + "signalr";
        
        this.signalrConnection = $.hubConnection(this.ConnectionUri, {
            useDefaultPath: false
        });

        this.CarinaWebSocketProxy = this.signalrConnection.createHubProxy('webLightGridHub');

        this.CarinaWebSocketProxy.connection.qs = { 'gridRuntimeId': '1234' };

        this.CarinaWebSocketProxy.on("receiveSnapShot", function (message)
        {
           alert(message);
        });
      
        this.signalRAction = new SignalRActions(this.CarinaWebSocketProxy);
       
       
    }

    Connect(handler)
    {
    
       this.signalrConnection.start({ waitForPageLoad: false }).done(function ()
        {

            alert("Connected to Signalr Server11");
           handler();

        })
      .fail(function (error)
      {
          alert("failed in connecting to the signalr server");
      })

      
    }

// Add=function("GetSnapShot",OnRender)
// {
//   Mapping{"GetSnapShot","recieveSnapShot"}
//   SingnalRProxy.On("recieveSnapShot",OnRender)

// }

// Invoke("GetSnapShot",data)
// {
//   SingnalRProxy.invoke("GetSnapShot",data);
// }




    //to do change to request 
    Send(key, value)
    {
        if (value == undefined)
        {
            this.CarinaWebSocketProxy.invoke(key);
        }
        else
        {
            this.CarinaWebSocketProxy.invoke(key,value);
        }
    };

}
class SignalRActions {
    constructor(webSocketProxy) {
        this.WebSocketProxy = webSocketProxy;

    }

    getSnapShotData(data) {
        var requestMessage = {
            "name": "getSnapShot",
            "viewPort": data.viewPort
        }
        this.WebSocketProxy.invoke('GetSnapShot', requestMessage);
        this.WebSocketProxy.on("recieveSnapShot", function (message) {
            console.log(message);
            if(data.element){
                return data.method(
                    {
                        "data":message,
                        "element":data.element
                    }
                );
            }else{
                return data.method(message);
            }

        })
    }
    getUpdateSnapShotData(data) {
        var requestMessage = {
            "name": "getSnapShot",
            "viewPort": data.viewPort
        }
        this.WebSocketProxy.invoke('GetUpdateSnapShot', requestMessage);
        this.WebSocketProxy.on("recieveUpdateSnapShot", function (message) {
            console.log(message);
            // if(data.element){
            //     return data.method(
            //         {
            //             "data":message,
            //             "element":data.element
            //         }
            //     );
            // }else{
            //     return data.method(message);
            // }
            return data.method(
                        {
                            "data":message,
                            "element":data.element
                        }
                    );
        })
    }

}
