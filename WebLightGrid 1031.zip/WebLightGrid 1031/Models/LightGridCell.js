function LightGridCell(rowIndex, columnIndex, formatInfo, id, data, width, height, color, background, textalign, display)
 {
      this.RowIndex = rowIndex;
      this.ColumnIndex = columnIndex;
      this.FormatInfo = formatInfo;
      this.Id = id ? id : 0;
      this.Data = data ? data : null;
      this.Width = width ? width : 0;
      this.Height = height ? height : 0;
      this.Color = color ? color : "black";
      this.Background = background ? background : "#a4a4a4";
      this.TextAlign = textalign ? textalign : "Left";
      this.Display = display ? display : "inline-block";
  
  }  