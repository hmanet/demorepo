function LightGridColumnRenderer(elme, header) 
{
    var element = document.createElement("div");
    element.setAttribute("id", header.Id);
    element.style["width"] = parseInt(header.Width) + 30 + "px";
    element.style["height"] = header.Height + "px";
    element.style["text-align"] = header.TextAlign;
    element.style["display"] = "inline-block";
    element.style["overflow"] = "hidden";
    element.style["position"] = "relative";
    element.style["top"] = "0px";
    return element;
}