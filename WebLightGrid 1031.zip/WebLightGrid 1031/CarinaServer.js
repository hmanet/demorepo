function CarinaServer(connectionUri)
{
    this.ConnectionUri = connectionUri;

    this.Send = function (key, value)
    {
        if (value == undefined)
        {
            $.ajax
            ({
                url: this.ConnectionUri + key,
                type: "Get",
                success: (data) => { this.ReceivedEvent.Invoke(key, data); },
                error: (data) => { return "Error with request: " + key; }
            });
        }
        else
        {
            $.ajax
            ({
                url: this.ConnectionUri + key,
                type: "Get",
                dataType: 'json',
                data: value,//TODO: translate to json if needed
                success: (data) => { this.ReceivedEvent.Invoke(key, data); },
                error: (data) => { return "Error with request: " + key; }
            });
        }
    };

    this.ReceivedEvent = new KeyedEvent();

    //TODO: anything below this line should be rmoved!

    this.ComponentSpec = function (callBack)
    {
        //Get Information Of ViewPort Data or First Request to Server for Grid Information
        var returnData;
        $.ajax
        ({
            url: this.ConnectionUri + "GetGridComponentSpec",
            type: "Get",
            dataType: 'json',
            success: (data) =>
            {
                console.log("scroll", data);
                //  returnData = data;
                // return data;
                callBack(data);
            },
            error: (data) =>
            {
                // alert(data);
                console.log("GridSpecError", data);
                return "Some thing is wrong!!";
            }
        });
    }

    server.Send("Snapshot")
    this.Send = function (viewport)
    {
        $.ajax
        ({
            url: this.ConnectionUri + 'GetSnapShot',
            type: 'GET',
            dataType: 'json',
            data: viewport,
            success: function (data)
            {
                GetSnapshotCallBack(data);

                // window.alert(isScuccess);
                //    offset = offset + 1;
            },
            error: function (request, message, error)
            {
                handleException(request, message, error);
            }
        });
     }
    this.Update = function (info)
    {
        $.ajax
        ({
            url: this.ConnectionUri + 'GetSnapShot',
            type: 'GET',
            dataType: 'json',
            data: info.viewport,
            success: function (data)
            {
                GetUpdateSnapshotCallBack(data, info.element);
            },
            error: function (request, message, error)
            {
                handleException(request, message, error);
            }
        });
    }
}