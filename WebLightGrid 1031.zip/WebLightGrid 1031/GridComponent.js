function GridComponent(server)
{
    function ctor()
    {
        this.server.ReceivedEvent.Add("GetGridComponentSpec", OnGridComponentSpecReceived);

        this.server.Send("GetGridComponentSpec");
    };
    this.server = server;

    this.Grid = new LightGrid(server);

    function OnGridComponentSpecReceived(spec)
    {
        var viewport = new Viewport(spec.totalRowCount, spec.gridRowsSize, 0);

        this.Grid.Viewport(viewport);
    };

    ctor();
};
