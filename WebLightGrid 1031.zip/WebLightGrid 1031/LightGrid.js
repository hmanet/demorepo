var gridElement;

function LightGrid(server)
{
    var ctor = function ()
    {
        this.server.Received.Add("GetSnapshot", OnInitialSnapshotReceived);
    };
    this.server = server;

    this.Viewport = function (value)
    {
        if(value == undefined)
        {
            return this.viewport;
        }
        else
        {
            this.viewport = value;

            this.server.Send("SetViewport", this.viewport);
        }
    };

    this.OnStanpshotReceived = function (value)
    {

    };

    this.OnInitialSnapshotReceived = function (value)
    {
        this.server.Received.Remove("GetSnapshot", OnInitialSnapshotReceived);
        this.server.Received.Add("GetSnapshot", OnSnapshotReceived);

        Initialize();
    };
    this.Initialize = function ()
    {
        if (gridComponentSpecData)
        {
            if (snapShot)
            {
                var viewportSize = CalculateViewportResolution(gridComponentSpecData, snapShot.columnsDescription);
                var viewportObj = new GridRenderer(viewportSize.width, viewportSize.height, gridComponentSpecData.gridRunTimeId, 0, 0);
                var viewport = CreateViewport(viewportObj);
                var headerSize = CalculateHeaderResolution(gridComponentSpecData, snapShot.columnsDescription)
                var headerObj = new LightGridColumn("LGH1", "", headerSize.width, headerSize.height);
                var header = LightGridColumnRenderer(viewport, headerObj);
                var viewportTotalContentSizes = CalculateViewportContentResolution(gridComponentSpecData, snapShot.columnsDescription);
                var viewportContentTotalObj = new ViewportContent("gridContent1", viewportTotalContentSizes.width, viewportTotalContentSizes.height)
                var viewportContentTotalElement = LightGridCreateTotalContent(viewportContentTotalObj);
                var ViewPortContentObj = new ViewportContent("LGVCD1", viewportTotalContentSizes.width, viewportObj.Height - gridComponentSpecData.columnHeaderHeight);
                var viewportContentElement = LightGridCreateContent(ViewPortContentObj);
                //Client Calculation of RowSize 
                var rowssize = Math.round(ViewPortContentObj.Height / gridComponentSpecData.rowHeight);
                gridComponentSpecData["gridRowsSize"] = rowssize;
                var headerElements = []
                for (var index = 0; index < snapShot.columnsDescription.length; index++)
                {
                    var cellData = snapShot.columnsDescription[index];
                    var cell = new LightGridColumn("col" + index, cellData.colName, cellData.width, gridComponentSpecData.columnHeaderHeight, cellData.color, cellData.bckground, cellData.text_align, cellData.display);
                    var element = CreateCell(cell)
                    headerElements.push(element);
                }

                if (headerElements.length) 
                {
                    for (var index = 0; index < headerElements.length; index++) 
                    {
                        header.appendChild(headerElements[index]);
                    }
                    viewport.appendChild(header);
                }

                var viewportRowsData = [];
                console.log(snapShot);
                for (var index = 0; index < gridComponentSpecData.gridRowsSize; index++)
                {
                    rowIndex = index * snapShot.columnsDescription.length;
                    var rowData = [];
                    for (var cellIndex = rowIndex; cellIndex < snapShot.columnsDescription.length * (index + 1); cellIndex++)
                    {
                        rowData.push(snapShot.cells[cellIndex]);
                    }
                    viewportRowsData.push(rowData)
                }
                var viewportContentRows = [];
                debugger
                if (viewportRowsData.length) 
                {
                    for (var index = 0; index < viewportRowsData.length; index++) 
                    {
                        var element = CreateRow(index, snapShot.columnsDescription.length, viewportRowsData[index], snapShot.columnsDescription);
                        viewportContentRows.push(element);
                    }
                }
                if (viewportContentRows.length)
                {
                    for (var index = 0; index < viewportContentRows.length; index++) 
                    {
                        viewportContentElement.appendChild(viewportContentRows[index])
                    }
                    viewport.appendChild(viewportContentElement);
                    viewport.appendChild(viewportContentTotalElement);
                }
            }
        }

        if (viewport)
        {
            gridElement = viewport;
            WindowOnLoad();
        }
    }

    this.OnShapshotReceived(value)
    {
        UpdateContent(snapShot.cells, element);
    };

    ctor();
};
