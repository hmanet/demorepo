﻿
function CalculateViewportResolution()
{
    var width = Math.round((window.innerWidth) * (50 / 100));
    var height = Math.round((window.innerHeight) * (0.50));
    sizes = new Size(width, height);
    return sizes;
}
function LightGridCreateContent(viewportContentObj)
{
    var element = document.createElement("div")
    element.setAttribute("id", viewportContentObj.Id);
    element.setAttribute("offsetLeft", viewportContentObj.OffsetLeft ? viewportContentObj.OffsetLeft : 0);
    element.setAttribute("offsetTop", viewportContentObj.OffsetTop ? viewportContentObj.OffsetTop : 0);
    element.style["width"] = parseInt(viewportContentObj.Width) + 30 + "px";
    element.style["height"] = viewportContentObj.Height + "px";
    element.style["position"] = "relative";
    element.style["top"] = "0px";
    return element;
}

function LightGridCreateTotalContent(contentobj)
{
    var element = document.createElement("div");
    element.setAttribute("id", contentobj.Id);
    element.setAttribute("offsetLeft", contentobj.OffsetLeft ? contentobj.OffsetLeft : 0);
    element.setAttribute("offsetTop", contentobj.OffsetTop ? contentobj.OffsetTop : 0);
    element.style["width"] = contentobj.Width + "px";
    element.style["height"] = contentobj.Height + "px";
    element.style["display"] = "inline-block";
    return element;
}

function LightGridCreateContent(viewportContentObj)
{
    var element = document.createElement("div")
    element.setAttribute("id", viewportContentObj.Id);
    element.setAttribute("offsetLeft", viewportContentObj.OffsetLeft ? viewportContentObj.OffsetLeft : 0);
    element.setAttribute("offsetTop", viewportContentObj.OffsetTop ? viewportContentObj.OffsetTop : 0);
    element.style["width"] = parseInt(viewportContentObj.Width) + 30 + "px";
    element.style["height"] = viewportContentObj.Height + "px";
    element.style["position"] = "relative";
    element.style["top"] = "0px";
    return element;
}

function LightGridCreateTotalContent(contentobj)
{
    var element = document.createElement("div");
    element.setAttribute("id", contentobj.Id);
    element.setAttribute("offsetLeft", contentobj.OffsetLeft ? contentobj.OffsetLeft : 0);
    element.setAttribute("offsetTop", contentobj.OffsetTop ? contentobj.OffsetTop : 0);
    element.style["width"] = contentobj.Width + "px";
    element.style["height"] = contentobj.Height + "px";
    element.style["display"] = "inline-block";
    return element;
}
function CreateRow(rowIndex, length, data, styledata)
{
    console.log(data);
    var element = document.createElement("div");
    for (var index = 0; index < length; index++)
    {
        // var subElement = document.createElement("div");
        var cellObj = new LightGridCell(data[index].data, data[index].formatInfo ? data[index].formatInfo : styledata[index]);
        var subElement = CreateCell(cellObj);
        element.appendChild(subElement);
    }
    element.style.height = styledata[0].height + "px";
    return element;
}

//function to create viewport 
function CreateViewport(viewportObj, obj)
{
    var element = document.createElement("div")
    element.setAttribute("id", viewportObj.Id);
    element.setAttribute("offsetTop", viewportObj.OffsetTop ? viewportObj.OffsetTop : 0);
    element.style["width"] = parseInt(viewportObj.Width) + 30 + "px";
    element.style["height"] = viewportObj.Height + 30 + "px";
    element.style["overflow"] = "scroll";
    obj.server.ReceivedEvent.Add("OnScroll", OnViewportScroll);

     //obj.webSocketClient.ReceivedEvent.Register("receiveSnapShot",this.OnSnapshotReceived.bind(this));
    //obj.server.ReceivedEvent.Add("OnUpdate", UpdateContent);

    element.addEventListener("scroll", function ($event)
    {
        //  obj.server.Send();
        //obj.webSocketClient.ReceivedEvent.Register("OnScroll",this.OnSnapshotReceived.bind(this));
        obj.server.ReceivedEvent.Invoke("OnScroll", { "domTarget": $event, "obj": obj });
    });
    return element;
}

function CalculateHeaderResolution(gridSpec, columnData)
{
    var sizes = {};
    var width = 0;
    for (var index = 0; index < columnData.length; index++)
    {
        width += parseInt(columnData[index].width);
    }
    var height = parseInt(gridSpec.columnHeaderHeight);
    //added '10', purpose of height 
    sizes["width"] = width;
    sizes["height"] = height;
    return sizes;
}


function CalculateViewportContentResolution(gridSpec, columndata)
{
    var sizes = {};
    var width = 0;
    for (var index = 0; index < columndata.length; index++)
    {
        width += parseInt(columndata[index].width);
    }
    // width=Math.round((window.width)*(50/100));
    var height = parseInt(gridSpec.totalRowCount) * parseInt(gridSpec.rowHeight);
    // var height = Math.round((window.height)*(50/100))

    sizes["width"] = width;
    sizes["height"] = height;
    return sizes;
}

function CreateCell(cell)
{
    var element = document.createElement("div");
    if (element)
    {
        element.setAttribute("id", cell.Id);
        element.style["width"] = cell.Width + "px";
        element.style["height"] = cell.Height + "px";
        element.style["color"] = cell.Foreground ? cell.Foreground : "#a4a4a4";
        element.style["background"] = cell.Background ? cell.Background : "#343434";
        element.style["text-align"] = cell.TextAlign ? cell.TextAlign : "left";
        // element.style["text-decoration-line"]=cell.TextUnderline?"underline":"none";
        // element.style["text-decoration-line"]=cell.TextStrikethrough?"line-through":"none";
        element.style["font-family"] = cell.FontFamily ? cell.FontFamily : "initial";
        element.style["font-size"] = cell.FontSize ? cell.FontSize + "px" : "initial";
        element.style["font-style"] = cell.FontStyle ? cell.FontStyle : "initial";
        element.style["font-weight"] = cell.FontWeight ? cell.FontWeight : "initial";
        element.style["border"] = (cell.cellBorder ? cell.cellBorder : "0.5") + "px solid";
        element.style["visibility"] = cell.Visible ? "visible" : "hidden";
        element.style["display"] = "inline-block";
        element.style["border"] = "0.5px solid ";
        element.style["overflow"] = "hidden";
        element.innerText = cell.Data;
    }
    return element;
}