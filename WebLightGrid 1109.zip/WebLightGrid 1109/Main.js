class Main
{
    constructor()
    {
        //this.server = new MockGridComponentServer();61752
         this.server = new CarinaServer("http://localhost:61752/api/LightGridController/");
        
       // this.server = new CarinaServer("http://localhost:8080/api/LightGridController/");

        this.component = new GridComponent(this.server);
    }   
};
