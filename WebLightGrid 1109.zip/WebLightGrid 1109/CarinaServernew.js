class CarinaServer
{
    constructor(connectionUri)
    {
        this.ConnectionUri = connectionUri;
        this.ReceivedEvent = new KeyedEvent();
    }
    window.CallbackPrefix = "receive";

    //to do change to request 
    Send(key, value)
    {
        if(window[window.CallbackPrefix + key] == undefined)
        {
            window[window.CallbackPrefix + key] = function(data)
            {
                queue.Add(function
                { 
                    this.ReceivedEvent.Invoke(key, data);
                    --window[window.CallbackPrefix + key + "refCount"];
                    if(window[window.CallbackPrefix + key + "refCount"] == 0) window[window.CallbackPrefix + key] = undefined;
                });
            };
            window[window.CallbackPrefix + key + "refCount"] = 1;
        }
        else ++window[window.CallbackPrefix + key + "refCount"];

        if (value == undefined)
        {
            return $.ajax
            ({
                url: this.ConnectionUri + key,
                type: "Get",
                success: (data) => { this.ReceivedEvent.Invoke(key, data); },
                error: (data) => { return "Error with request: " + key; }
            });
        }
        else
        {
            return $.ajax
            ({
                url: this.ConnectionUri + key,
                type: "Get",
                dataType: 'json',
                data: value.value,
                success: (data) =>
                {
                    debugger
                    if (value.updateData)
                    {
                        value.updateData.data = data;
                        this.ReceivedEvent.Invoke(value.event, value.updateData);
                    } else
                    {
                        debugger
                        this.ReceivedEvent.Invoke(value.event, data);
                    }

                },
                error: (data) => { return "Error with request: " + key; }
            });
        }
    };

}