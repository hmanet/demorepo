class CarinaServer
{
    constructor(connectionUri)
    {
        this.ConnectionUri = connectionUri;
        this.ReceivedEvent = new KeyedEvent();
    }

    Send(key, value)
    {
        if (value == undefined)
        {
            return $.ajax
            ({
                url: this.ConnectionUri + key,
                type: "Get",
                success: (data) => { this.ReceivedEvent.Invoke(key, data); },
                error: (data) => { return "Error with request: " + key; }
            });
        }
        else
        {
            return $.ajax
            ({
                url: this.ConnectionUri + key,
                type: "Get",
                dataType: 'json',
                data: value.value,//TODO: translate to json if needed
                success: (data) => { 
                    debugger
                    if(value.updateData){
                        value.updateData.data=data;
                        this.ReceivedEvent.Invoke(value.event, value.updateData); 
                    }else{
                        debugger
                        this.ReceivedEvent.Invoke(value.event, data);                         
                    }

                },
                error: (data) => { return "Error with request: " + key; }
            });
        }
    };

}