class CarinaWebSocketClient
{
    constructor(connectionUri)
    {
        this.ConnectionUri = connectionUri + "signalr";
        
        this.signalrConnection = $.hubConnection(this.ConnectionUri, {
            useDefaultPath: false
        });

        this.CarinaWebSocketProxy = this.signalrConnection.createHubProxy('webLightGridHub');

        this.CarinaWebSocketProxy.connection.qs = { 'gridRuntimeId': '1234' };

        this.CarinaWebSocketProxy.on("receiveSnapShot", function (message)
        {
           //alert(message);
        });
      
        this.ReceivedEvent = new SignalRKeyedEvent(this.CarinaWebSocketProxy);
       
    }

    Connect(handler)
    {
    
       this.signalrConnection.start({ waitForPageLoad: false }).done(function ()
        {

            alert("Connected to Signalr Server11");
           handler();

        })
      .fail(function (error)
      {
          alert("failed in connecting to the signalr server");
      })

      
    }

//Server.Add("GetSnapShot",OnRender)
//{
//  Mapping{"GetSnapShot","recieveSnapShot"}
//  SingnalRProxy.On("recieveSnapShot",OnRender)

//}

//Server.Invoke("GetSnapShot",data)
//{
//  SingnalRProxy.invoke("GetSnapShot",data);
//}




    //to do change to request 
    Send(key, value)
    {
        if (value == undefined)
        {
            this.CarinaWebSocketProxy.invoke(key);
        }
        else
        {
            this.CarinaWebSocketProxy.invoke(key,value);
        }
    };

}