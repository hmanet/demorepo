function KeyedEvent()
{
    this.handlers = {};

    this.Add = function (key, handler)
    {
        if (this.handlers[key] == null) this.handlers[key] = new Array();

        this.handlers[key].push(handler);
    }
    this.Remove = function (key, handler)
    {
        if (this.handlers[key] == null) return;

        let index = this.handlers[key].indexOf(handler);
        if (index >= 0) this.handlers[key].splice(index, 1);
    }

    this.Invoke = function (key, value)
    {
        let h = this.handlers[key];
        if (h == undefined) return;

        for (let i = 0; i < h.length; ++i) h[i](value);
    }
}

class SignalRKeyedEvent
{
    constructor(webSocketProxy)
    {
        this.WebSocketProxy = webSocketProxy;
    }


    Register(receiver,handler)
    {
        this.WebSocketProxy.on(receiver,handler);
    }

    UnRegister(receiver, handler)
    {
        
    }
}
