function LightGridCell(cellData,data)
 {
      // this.RowIndex = rowIndex;
      // this.ColumnIndex = columnIndex;
      // this.FormatInfo = formatInfo;
      // this.Id = id ? id : 0;
      // this.Data = data ? data : null;
      // this.Width = width ? width : 0;
      // this.Height = height ? height : 0;S
      // this.Color = color ? color : "black";
      // this.Background = background ? background : "#a4a4a4";
      // this.TextAlign = textalign ? textalign : "Left";
      // this.Display = display ? display : "inline-block";

      var styleInfo=data.formatInfo;
      this.Data =cellData ;
      this.Height=data.height;
      this.Width=data.width;
      this.Background =styleInfo.background;
      this.BackgroundBlendMode =styleInfo.blendBackground;
      this.cellBorder =styleInfo.cellBorder;
      this.Editable =styleInfo.editable;
      this.FontFamily=styleInfo.fontFamily;
      this.FontStyle=styleInfo.FontStyle;
      this.FontSize=styleInfo.fontSize;
      this.FontWeight=styleInfo.FontWeight;
      this.Foreground=styleInfo.foreground;
      this.RowBorder=styleInfo.rowBorder;
      this.TextUnderline=styleInfo.underline;
      this.TextStrikethrough=styleInfo.strikethrough;
      this.Visible=styleInfo.visible;
  
  }  