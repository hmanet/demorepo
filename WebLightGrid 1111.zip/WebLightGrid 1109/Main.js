class Main
{
    constructor()
    {

        var serverUrl = "http://localhost:61752/";
        var carinaWebSocketServerUrl = serverUrl + "signalr";
        //this.server = new MockGridComponentServer();
        // this.server = new CarinaServer("http://localhost:8080/api/LightGridController/");
      // this.server = new CarinaServer("http://localhost:61752/api/LightGridController/");
        
        this.webSocketClient = new CarinaWebSocketClient(carinaWebSocketServerUrl);
        this.webSocketClient.Connect(this.OnConnectionEstablished.bind(this));

    }

    OnConnectionEstablished()
        {
            this.component = new GridComponent(this.server,this.webSocketClient);
        };
};
