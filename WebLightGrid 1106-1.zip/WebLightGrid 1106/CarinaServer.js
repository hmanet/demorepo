class CarinaServer
{
    constructor(connectionUri)
    {
        this.ConnectionUri = connectionUri;
        this.ReceivedEvent = new KeyedEvent();
    }

    Send(key, value)
    {
        if (value == undefined)
        {
            return $.ajax
            ({
                url: this.ConnectionUri + key,
                type: "Get",
                success: (data) => { this.ReceivedEvent.Invoke(key, data); },
                error: (data) => { return "Error with request: " + key; }
            });
        }
        else
        {
            return $.ajax
            ({
                url: this.ConnectionUri + key,
                type: "Get",
                dataType: 'json',
                data: value,//TODO: translate to json if needed
                success: (data) => { this.ReceivedEvent.Invoke(value.event, data); },
                error: (data) => { return "Error with request: " + key; }
            });
        }
    };

}