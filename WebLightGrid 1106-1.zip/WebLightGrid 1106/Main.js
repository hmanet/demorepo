class Main
{
    constructor()
    {
        //this.server = new MockGridComponentServer();
        this.server = new CarinaServer("http://localhost:8080/api/LightGridController/");

        this.component = new GridComponent(this.server);
    }   
};
