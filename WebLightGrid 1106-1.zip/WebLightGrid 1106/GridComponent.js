class GridComponent
{
    constructor(server)
    {
        this.server = server;
        this.Grid = new LightGrid(server);
        this.spec = new GridComponentSpec();

        server.ReceivedEvent.Add("GetGridComponentSpec", this.OnGridComponentSpecReceived);

        server.Send("GetGridComponentSpec");
    };
    OnGridComponentSpecReceived(spec)
    {
        this.spec = spec;

        var size = CalculateViewportResolution();
        var viewport = new Viewport(spec.TotalRowCount, Math.round(size.Height / spec.RowHeight) , 0);
        
        this.Grid.Viewport(viewport, spec);
    };
    //TODO: this has to be done somewhere in html
    CalculateViewportResolution()
    {
        var width = Math.round((window.innerWidth) * (50 / 100));
        var height = Math.round((window.innerHeight) * (0.25));

        return new Size(width, height);
    }
};
