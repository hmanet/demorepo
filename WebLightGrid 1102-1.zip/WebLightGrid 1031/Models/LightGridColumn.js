function LightGridColumn(id, data, width, height, offsetleft, offsettop, background, textalign, display)
 {
    this.Id = id || 0;
    this.Data = data;
    this.Width = width;
    this.Height = height;
    this.OffsetLeft = offsetleft ? offsetleft : 0;
    this.OffsetTop = offsettop ? offsettop : 0;
    this.Background = background ? background : "#343434";
    this.TextAlign = textalign ? textalign : "left";
    this.Display = display ? display : "inline-block";
}

/*function LightGridCreateHeaderCells(elme, ColumnData) {
    for (var index = 0; index < ColumnData.length; index++) {
        var Eelement = createElement("div");
        Element.setAttribute("Id", ColumnData[index].id)

    }
} */