﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using LightGridSample.Models;

namespace LightGridSample.Controllers
{
    public class LightGridController : ApiController
    {
        public LightGridController()
        { }

        [Route("api/LightGridController/GetGridComponentSpec")]
        [HttpGet]
        public GridComponentSpec GetGridComponentSpec()
        {
            return new GridComponentSpec() {DisplayRowCount = 10,GridRunTimeId = 21234,GridType = "Showcase",RowHeight=20,TotalRowCount = 100};
        }

        
        [Route("api/LightGridController/GetSnapShot")]
        [HttpGet]
        public SnapShot GetSnapShot([FromUri]ViewPort viewPort)
        {
            var snapshot = CarinaSnapShotBuilder.GetSnapShot(viewPort);
            return snapshot;
        }
    }
}


//  $.ajax({
//    url: 'http://localhost:55449/api/LightGridController/GetSnapShot',
//              type: 'GET',
//              dataType: 'json',
//              data: { "count":100,"size":10,"offset":offset},
//              success: function(isScuccess) {
//        window.alert(isScuccess);
//        offset = offset + 1;
//    },
//              error: function(request, message, error) {
//        handleException(request, message, error);
//    }

//});