﻿using Newtonsoft.Json;

namespace LightGridSample.Models
{
    public class Size
    {
        [JsonProperty(PropertyName = "height")]
        public string Height { get; set; }

        [JsonProperty(PropertyName = "width")]
        public string Width { get; set; }

    }
}