﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace LightGridSample.Models
{
    public class SnapShot
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "rowCount")]
        public int RowCount { get; set; }

        [JsonProperty(PropertyName = "rowCellCount")]
        public int RowCellCount { get; set; }

        [JsonProperty(PropertyName = "columnsDescription")]
        public List<LightGridColumn> Columns { get; set; }

        [JsonProperty(PropertyName = "cells")]
        public List<LightGridCell> Cells { get; set; }
    }
}