var gridElement;

class LightGrid
{
    // var ctor = function (obj)
    // {
    //     // obj.server.ReceivedEvent.Add("Intialize", obj.OnInitialize);
    //     obj.server.ReceivedEvent.Add("Viewport",obj.Viewport);
    //     obj.server.ReceivedEvent.Add("Intialize",obj.OnInitialize);
    //     // obj.server.ReceivedEvent.Add("IntialsnapShot");
    // };
    constructor(server){
        this.server = server ;
        this.gridComponentSpecData;
        this.snapShot;
        server.ReceivedEvent.Add("Viewport",this.Viewport);
        server.ReceivedEvent.Add("Intialize",this.OnInitialize);
    }
    

    Viewport (value,spec)
    {
        if(value == undefined)
        {
            return this.viewport;
        }
        else
        {
            this.gridComponentSpecData=spec;
            var viewport = value;
            this.server.Send("GetSnapshot",viewport ).then(
                data=>{ 
                    this.snapShot=data;
                    this.OnInitialize(data) 
                },
                error=>{});
        }
    };

    OnStanpshotReceived (value)
    {

    };

    OnInitialSnapshotReceived (value)
    {
        this.server.Received.Remove("GetSnapshot", OnInitialSnapshotReceived);
        this.server.Received.Add("GetSnapShot", OnSnapshotReceived);

        Initialize();
    };
    OnInitialize ()
    {
        if (this.gridComponentSpecData)
        {
            if (this.snapShot)
            {
                var viewportSize = CalculateViewportResolution(this.gridComponentSpecData, this.snapShot.columnsDescription);
                var viewportObj = new GridRenderer(viewportSize.width, viewportSize.height, this.gridComponentSpecData.gridRunTimeId, 0, 0);
                var viewport = CreateViewport(viewportObj,this);
                var headerSize = CalculateHeaderResolution(this.gridComponentSpecData, this.snapShot.columnsDescription)
                var headerObj = new LightGridColumn("LGH1", "", headerSize.width, headerSize.height);
                var header = LightGridColumnRenderer(viewport, headerObj);
                var viewportTotalContentSizes = CalculateViewportContentResolution(this.gridComponentSpecData, this.snapShot.columnsDescription);
                var viewportContentTotalObj = new ViewportContent("gridContent1", viewportTotalContentSizes.width, viewportTotalContentSizes.height)
                var viewportContentTotalElement = LightGridCreateTotalContent(viewportContentTotalObj);
                var ViewPortContentObj = new ViewportContent("LGVCD1", viewportTotalContentSizes.width, viewportObj.Height - this.gridComponentSpecData.columnHeaderHeight);
                var viewportContentElement = LightGridCreateContent(ViewPortContentObj);
                //Client Calculation of RowSize 
                var rowssize = Math.round(ViewPortContentObj.Height / this.gridComponentSpecData.rowHeight);
                this.gridComponentSpecData["gridRowsSize"] = rowssize;
                var headerElements = []
                for (var index = 0; index < this.snapShot.columnsDescription.length; index++)
                {
                    var cellData = this.snapShot.columnsDescription[index];
                    var cell = new LightGridColumn("col" + index, cellData.colName, cellData.width, this.gridComponentSpecData.columnHeaderHeight, cellData.color, cellData.bckground, cellData.text_align, cellData.display);
                    var element = CreateCell(cell)
                    headerElements.push(element);
                }

                if (headerElements.length) 
                {
                    for (var index = 0; index < headerElements.length; index++) 
                    {
                        header.appendChild(headerElements[index]);
                    }
                    viewport.appendChild(header);
                }

                var viewportRowsData = [];
                console.log(this.snapShot);
                for (var index = 0; index < this.gridComponentSpecData.gridRowsSize; index++)
                {
                    var rowIndex = index * this.snapShot.columnsDescription.length;
                    var rowData = [];
                    for (var cellIndex = rowIndex; cellIndex < this.snapShot.columnsDescription.length * (index + 1); cellIndex++)
                    {
                        rowData.push(this.snapShot.cells[cellIndex]);
                    }
                    viewportRowsData.push(rowData)
                }
                var viewportContentRows = [];
                debugger
                if (viewportRowsData.length) 
                {
                    for (var index = 0; index < viewportRowsData.length; index++) 
                    {
                        var element = CreateRow(index, this.snapShot.columnsDescription.length, viewportRowsData[index], this.snapShot.columnsDescription);
                        viewportContentRows.push(element);
                    }
                }
                if (viewportContentRows.length)
                {
                    for (var index = 0; index < viewportContentRows.length; index++) 
                    {
                        viewportContentElement.appendChild(viewportContentRows[index])
                    }
                    viewport.appendChild(viewportContentElement);
                    viewport.appendChild(viewportContentTotalElement);
                }
            }
        }

        if (viewport)
        {
            gridElement = viewport;
            WindowOnLoad();
        }
    }

    // this.OnShapshotReceived(value)
    // {
    //     UpdateContent(this.snapShot.cells, element);
    // };

    // ctor(this);
};
