﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wells.Carina.Web.API.Hubs
{
    public static class WebLightGridSources
    {
        private static readonly ConcurrentDictionary<string, IWebLightGridSource> gridsById = new ConcurrentDictionary<string, IWebLightGridSource>();

        public static IWebLightGridSource GetSource(string id)
        {
            //lock (gridsById)
            {
                IWebLightGridSource value;
                gridsById.TryGetValue(id, out value);
                return value;
            }
        }

        public static void AddSource(string id, IWebLightGridSource source)
        {
            //lock (gridsById)
            {
                gridsById.TryAdd(id, source);
            }
        }

        public static bool RemoveSource(string id)
        {
            //lock (gridsById)
            {
                IWebLightGridSource source;
               return gridsById.TryRemove(id,out source);
            }
        }

        public static IWebLightGridSource GetDefaultSource()
        {
            return gridsById.Values.FirstOrDefault();
        }
    }
}
