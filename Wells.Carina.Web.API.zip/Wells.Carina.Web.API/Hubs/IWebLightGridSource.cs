﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Requests;

namespace Wells.Carina.Web.API.Hubs
{
    public interface IWebLightGridSource
    {
        string GridId { get; }
        void AttachClient(IClient client);
        void GetComponentSpec();
        void GetGridSpec();
        void ProcessSnapshotRequests(WebGridRequest request);
    }
}
