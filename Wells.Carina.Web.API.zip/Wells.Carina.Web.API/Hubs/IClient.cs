﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Responses;

namespace Wells.Carina.Web.API.Hubs
{
    public interface IClient
    {
        void ReceiveGridComponentSpec(GridComponentSpecResponse spec);
        void ReceiveGridSpec(GridSpecResponse spec);
        void ReceiveSnapshot(SnapshotResponse snapShot);
    }
}
