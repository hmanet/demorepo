﻿using System.Collections.Generic;
using System.Linq;

namespace Wells.Carina.Web.API.Hubs
{
    public class ConnectionMapping<T>
    {
        private readonly Dictionary<T, KeyValuePair<string,CarinaHubBase>> connections =
            new Dictionary<T, KeyValuePair<string, CarinaHubBase>>();

        public int Count
        {
            get
            {
                return connections.Count;
            }
        }

        public void Add(T key, string connectionId,CarinaHubBase hub)
        {
            lock (connections)
            {
                KeyValuePair<string, CarinaHubBase> connectionHubPair = new KeyValuePair<string, CarinaHubBase>(connectionId,hub);
                if (!connections.ContainsKey(key))
                {
                    connections.Add(key, connectionHubPair);
                }
                
            }
        }

        public KeyValuePair<string, CarinaHubBase> GetConnection(T key)
        {
            KeyValuePair<string, CarinaHubBase> connectionHubPair;
            lock (connections)
            {
                connections.TryGetValue(key, out connectionHubPair);
            }
            return connectionHubPair;
        }

        public void Remove(T key)
        {
            lock (connections)
            {
                connections.Remove(key);
            }
        }
    }
}
