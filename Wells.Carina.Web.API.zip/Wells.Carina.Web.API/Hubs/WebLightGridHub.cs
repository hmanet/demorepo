﻿using Wells.Carina.Web.API.Models.Requests;


namespace Wells.Carina.Web.API.Hubs
{
    public class WebLightGridHub : CarinaHubBase
    {
        public WebLightGridHub() : base()
        {
            
        }
        
        public void GetComponentSpec()
        {
            //string gridRunTimeId = Context.QueryString["gridRuntimeId"];
            // Ideally the UI client should send an identifier to idenfiy which source it is communicating.
            // Need to think of a better way of handling this.
            string gridRunTimeId = Context.QueryString["gridRuntimeId"];

            var gridSource = WebLightGridSources.GetSource(gridRunTimeId);

            gridSource.GetComponentSpec();
        }

        public void GetGridSpec()
        {
            string gridRunTimeId = Context.QueryString["gridRuntimeId"];

            var gridSource = WebLightGridSources.GetSource(gridRunTimeId);

            gridSource.GetGridSpec();
        }

        public void GetSnapShot(UpdateViewPortRequest request)
        {
            string gridRunTimeId = Context.QueryString["gridRuntimeId"];

            var gridSource = WebLightGridSources.GetSource(gridRunTimeId);
            gridSource.ProcessSnapshotRequests(request);
        }
        

    }

}
