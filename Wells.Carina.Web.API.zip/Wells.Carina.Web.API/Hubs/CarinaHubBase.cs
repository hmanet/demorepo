﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using Microsoft.AspNet.SignalR;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Responses;

namespace Wells.Carina.Web.API.Hubs
{
    
    public abstract class CarinaHubBase : Hub, IClient
    {
        protected static ConnectionMapping<string> connections = new ConnectionMapping<string>();
        protected CarinaHubBase()
        {
        }

        public override Task OnConnected()
        {
            string gridRunTimeId = Context.QueryString["gridRuntimeId"];

            if (!string.IsNullOrEmpty(gridRunTimeId))
            {
                connections.Remove(gridRunTimeId);
                connections.Add(gridRunTimeId, Context.ConnectionId, this);
                var gridSource = WebLightGridSources.GetSource(gridRunTimeId);
                gridSource.AttachClient(this);
            }
            else
            {
                // Need to think of a better way of handling as we need an identifer for the communication.
                var gridSource = WebLightGridSources.GetDefaultSource();
                gridSource.AttachClient(this);
            }
            return base.OnConnected();
        }

        public override Task OnDisconnected(bool stopCalled)
        {
            string gridRunTimeId = Context.QueryString["gridRuntimeId"];

            //connections.Remove(gridRunTimeId);
            
            return base.OnDisconnected(stopCalled);
        }

        public override Task OnReconnected()
        {
            string gridRunTimeId = Context.QueryString["gridRuntimeId"];
            var connectionDetails = connections.GetConnection(gridRunTimeId);

            if (!string.IsNullOrEmpty(connectionDetails.Key)  && connectionDetails.Key.Contains(Context.ConnectionId))
            {
                connections.Add(gridRunTimeId, Context.ConnectionId, this);
                var gridSource = WebLightGridSources.GetSource(gridRunTimeId);
                gridSource.AttachClient(this);
            }

            return base.OnReconnected();
        }

        public void ReceiveGridComponentSpec(GridComponentSpecResponse spec)
        {
            var connectionDetails = connections.GetConnection(spec.GridId);
            Clients.Client(connectionDetails.Key).receiveGridComponentSpec(spec);
        }

        public void ReceiveGridSpec(GridSpecResponse spec)
        {
            var connectionDetails = connections.GetConnection(spec.GridId);
            Clients.Client(connectionDetails.Key).receiveGridSpec(spec);
        }

        public void ReceiveSnapshot(SnapshotResponse snapShot)
        {
            var connectionDetails = connections.GetConnection(snapShot.GridId);
            Clients.Client(connectionDetails.Key).receiveSnapShot(snapShot);
        }
    }
}
