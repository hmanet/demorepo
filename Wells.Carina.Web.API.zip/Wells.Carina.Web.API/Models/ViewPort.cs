﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class ViewPort
    {
        public int Size { get; set; }

        public int Count { get; set; }

        public int Offset { get; set; }

    }
}