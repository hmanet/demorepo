﻿using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class Size
    {
        [JsonProperty(PropertyName = "height")]
        public string Height { get; set; }

        [JsonProperty(PropertyName = "width")]
        public string Width { get; set; }

    }
}