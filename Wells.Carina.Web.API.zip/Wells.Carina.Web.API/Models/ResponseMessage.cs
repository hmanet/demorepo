﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class ResponseMessage
    {
        [JsonProperty(PropertyName = "action")]
        public string Action { get; set; }

        [JsonProperty(PropertyName = "gridSnapShot")]
        public SnapShot GridSnapShot { get; set; }
    }
}
