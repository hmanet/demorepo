﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class RequestMessage
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "viewPort")]
        public ViewPort ViewPort { get; set; }
    }
}
