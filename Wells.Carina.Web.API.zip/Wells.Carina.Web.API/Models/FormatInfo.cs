﻿using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class FormatInfo
    {
        [JsonProperty(PropertyName = "editable")]
        public bool Editable { get; set; }

        [JsonProperty(PropertyName = "foreground")]
        public string Foreground { get; set; }

        [JsonProperty(PropertyName = "background")]
        public string Background { get; set; }

        [JsonProperty(PropertyName = "fontFamily")]
        public string FontFamily { get; set; }

        [JsonProperty(PropertyName = "fontWeight")]
        public string FontWeight { get; set; }

        [JsonProperty(PropertyName = "fontStyle")]
        public string FontStyle { get; set; }

        [JsonProperty(PropertyName = "fontSize")]
        public string FontSize { get; set; }

        [JsonProperty(PropertyName = "visible")]
        public bool Visible { get; set; }

        [JsonProperty(PropertyName = "strikethrough")]
        public string Strikethrough { get; set; }

        [JsonProperty(PropertyName = "underline")]
        public string Underline { get; set; }

        [JsonProperty(PropertyName = "blendBackground")]
        public string BlendBackground { get; set; }

        [JsonProperty(PropertyName = "rowBorder")]
        public string RowBorder { get; set; }

        [JsonProperty(PropertyName = "cellBorder")]
        public string CellBorder { get; set; }
    }
}