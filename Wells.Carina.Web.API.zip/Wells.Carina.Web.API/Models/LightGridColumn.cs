﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class LightGridColumn
    {
        [JsonProperty(PropertyName = "colName")]
        public string ColName { get; set; }

        [JsonProperty(PropertyName = "width")]
        public int Width { get; set; }

        [JsonProperty(PropertyName = "height")]
        public int Height { get; set; }

        [JsonProperty(PropertyName = "formatInfo")]
        public FormatInfo FormatInfo { get; set; }

    }
}