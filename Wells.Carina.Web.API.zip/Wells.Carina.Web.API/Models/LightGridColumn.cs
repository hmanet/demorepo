﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class LightGridColumn
    {
        public string Name { get; set; }

        public double Width { get; set; }

        public bool Editable { get; set; }

        public string Foreground { get; set; }

        public string Background { get; set; }

        public string FontFamily { get; set; }

        public string FontWeight { get; set; }

        public string FontStyle { get; set; }

        public string FontSize { get; set; }

        public bool Visible { get; set; }

        public string Strikethrough { get; set; }

        public string Underline { get; set; }

        public double Scaling { get; set; }

        public int DecimalPlaces { get; set; }

        public string RowBorder { get; set; }

        public string CellBorder { get; set; }

    }
}