﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wells.Carina.Web.API.Models.Requests
{
    public class UpdateViewPortRequest : WebGridRequest
    {
        public ViewPort HorizontalViewport { get; set; }

        public ViewPort VerticalViewport { get; set; }
    }
    
}
