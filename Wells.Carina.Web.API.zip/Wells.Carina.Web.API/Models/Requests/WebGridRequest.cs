﻿namespace Wells.Carina.Web.API.Models.Requests
{
    public class WebGridRequest
    {
        public string Name { get; set; }

        public int RequestId { get; set; }

        public int Id { get; set; }
    }
}
