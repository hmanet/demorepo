﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wells.Carina.Web.API.Models.Responses
{
    public abstract class WebGridResponse
    {
        public string GridId { get; set; }
    }
}
