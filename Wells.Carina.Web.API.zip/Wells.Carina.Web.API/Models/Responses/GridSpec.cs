﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wells.Carina.Web.API.Models.Responses;

namespace Wells.Carina.Web.API.Models.Responses
{
    public class GridSpecResponse : WebGridResponse
    {
        public int HeadersHeight { get; set; }

        public int RowHeight { get; set; }

        public IList<LightGridColumn> Columns { get; set; }
    }
}
