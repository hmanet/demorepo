﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using Wells.Carina.Web.API.Models.Responses;

namespace Wells.Carina.Web.API.Models.Responses
{
    public class SnapshotResponse : WebGridResponse
    {
        public ViewPort HorizontalViewport { get; set; }
        public ViewPort VerticalViewport { get; set; }

        public List<LightGridColumn> Columns { get; set; }
        
        public List<LightGridCell> Cells { get; set; }
        public int RowHeight { get; set; }

    }
}