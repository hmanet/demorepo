﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using Wells.Carina.Web.API.Models.Responses;

namespace Wells.Carina.Web.API.Models.Responses
{
    public class GridComponentSpecResponse : WebGridResponse
    {
        public string Type { get; set; }

        public string RunTimeId { get; set; }

        //public double ColumnHeaderHeight { get; set; }

        //public double RowHeight { get; set; }

        //public int TotalRowCount { get; set; }
    }
}