﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class SnapShot
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "rowHeight")]
        public int RowHeight { get; set; }

        [JsonProperty(PropertyName = "columnSpecs")]
        public List<LightGridColumn> Columns { get; set; }

        [JsonProperty(PropertyName = "cells")]
        public List<LightGridCell> Cells { get; set; }
    }
}