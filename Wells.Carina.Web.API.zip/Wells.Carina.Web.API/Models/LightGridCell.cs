﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class LightGridCell
    {
        [JsonProperty(PropertyName = "Data")]
        public object Data { get; set; }

        [JsonProperty(PropertyName = "RowIndex")]
        public int RowIndex { get; set; }

        [JsonProperty(PropertyName = "ColumnIndex")]
        public int ColumnIndex { get; set; }

        [JsonProperty(PropertyName = "FormatInfo")]
        public FormatInfo FormatInfo { get; set; }

        [JsonProperty(PropertyName = "Top")]
        public int Top { get; set; }

        [JsonProperty(PropertyName = "Left")]
        public int Left { get; set; }
    }
}