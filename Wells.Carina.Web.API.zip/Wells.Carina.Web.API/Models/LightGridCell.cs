﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using ProtoBuf;

namespace Wells.Carina.Web.API.Models
{
    public class LightGridCell
    {
        public object Data { get; set; }

        public int RowIndex { get; set; }

        public int ColumnIndex { get; set; }

        public FormatInfo FormatInfo { get; set; }

        public double Top { get; set; }

        public double Left { get; set; }
    }
}