﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Wells.Carina.Web.API.Models;


namespace Wells.Carina.Web.API
{
    public static class CarinaSnapShotBuilder
    {
        // just a varibale to hold
        private static SnapShot snapShot = new SnapShot();

        public static int Rows { get; set; }

        public static void Initialize(int rows)
        {
            Rows = rows;
            snapShot.RowHeight = 20;
            snapShot.Columns = new List<LightGridColumn>();
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Density",
                Width = 80,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
                
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Description",
                Width = 80,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
                
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Discovery Date",
                Width = 80,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1

            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Has Atmosphere",
                Width = 90,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
                
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Mass",
                Width = 50,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1

                
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Name",
                Width = 60,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
                
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Note",
                Width = 80,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
                
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Orbit Distance (Miles)",
                Width = 120,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Orbital Period (Days)",
                Width = 110,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
               
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Orbits",
                Width = 80,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
                
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Radius",
                Width = 80,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
                
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Random",
                Width = 80,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
                
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Ranking",
                Width = 80,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
                
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Satellites",
                Width = 80,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
               
            });
            snapShot.Columns.Add(new LightGridColumn()
            {
                Name = "Type",
                Width = 80,
                Editable = true,
                Foreground = "red",
                Background = "#00FFFFFF",
                FontFamily = "verdana",
                FontWeight = "bold",
                FontStyle = "oblique",
                FontSize = "10",
                Visible = true,
                Strikethrough = "false",
                Underline = "false",
                DecimalPlaces = 1,
                Scaling = 1
               
            });

            snapShot.Cells = new List<LightGridCell>();
            var top = 0;
            for (int row = 0; row < rows; ++row)
            {

                for (int i = 0; i < snapShot.Columns.Count; ++i)
                    snapShot.Cells.Add(new LightGridCell()
                    {
                        Data = "Data_" + row,
                        RowIndex = row,
                        ColumnIndex = i
                    });
            }
        }

        public static SnapShot GetSnapShot(ViewPort viewPort)
        {

            int from;
            int to;

            // Boundary condition
            if (viewPort.Offset + viewPort.Size > Rows)
            {
                from = (Rows * snapShot.Columns.Count) - (viewPort.Size * snapShot.Columns.Count);
                to = from + viewPort.Size * snapShot.Columns.Count;
            }
            else
            {
                from = viewPort.Offset * snapShot.Columns.Count;
                to = from + viewPort.Size * snapShot.Columns.Count;
            }

            List<LightGridCell> cells = new List<LightGridCell>();


            var rowCount = 0;
            var tempRowCount = 0;
            var tempLeft = 0;
            var cellCount = 0;
            var top = 0;
            var left = 0;
             
            for (int i = from; i < to; ++i)
            {
                

                var cell = snapShot.Cells[i];
                cell.Top = rowCount*snapShot.RowHeight;
                

                cell.Left = tempLeft == 0?0:tempLeft ;

                if (tempLeft == 0)
                {
                    tempLeft = snapShot.Columns[tempRowCount].Width;
                }
                else
                {
                    tempLeft = tempLeft + +snapShot.Columns[tempRowCount].Width;
                }
                cells.Add(cell);

                tempRowCount++;

                if (tempRowCount == snapShot.Columns.Count)
                {
                    rowCount++;
                    tempRowCount = 0;
                    tempLeft = 0;
                }

            }

            SnapShot tempSnapShot = new SnapShot();
            tempSnapShot.Columns = snapShot.Columns;
            tempSnapShot.Cells = cells;
           
            // 10,0
            // from = 0,to = 0+10*10

            // 10,1
            // from = 10,to=10+10*10

            //10,2
            //from = 20,to=20+10*10

            return tempSnapShot;
        }
    }


}