﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class GridComponentSpec
    {
        [JsonProperty(PropertyName = "GridType")]
        public string GridType { get; set; }

        [JsonProperty(PropertyName = "GridRunTimeId")]
        public int GridRunTimeId { get; set; }

        [JsonProperty(PropertyName = "RowHeight")]
        public int RowHeight { get; set; }

        [JsonProperty(PropertyName = "TotalRowCount")]
        public int TotalRowCount { get; set; }

        [JsonProperty(PropertyName = "ColumnHeaderHeight")]
        public int ColumnHeaderHeight { get; set; }
         
    }
}