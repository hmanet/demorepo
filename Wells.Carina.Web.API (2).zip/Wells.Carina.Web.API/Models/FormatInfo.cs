﻿using Newtonsoft.Json;

namespace Wells.Carina.Web.API.Models
{
    public class FormatInfo
    {
        [JsonProperty(PropertyName = "Editable")]
        public bool Editable { get; set; }

        [JsonProperty(PropertyName = "Foreground")]
        public string Foreground { get; set; }

        [JsonProperty(PropertyName = "Background")]
        public string Background { get; set; }

        [JsonProperty(PropertyName = "FontFamily")]
        public string FontFamily { get; set; }

        [JsonProperty(PropertyName = "FontWeight")]
        public string FontWeight { get; set; }

        [JsonProperty(PropertyName = "FontStyle")]
        public string FontStyle { get; set; }

        [JsonProperty(PropertyName = "FontSize")]
        public string FontSize { get; set; }

        [JsonProperty(PropertyName = "Visible")]
        public bool Visible { get; set; }

        [JsonProperty(PropertyName = "Strikethrough")]
        public string Strikethrough { get; set; }

        [JsonProperty(PropertyName = "Underline")]
        public string Underline { get; set; }

        [JsonProperty(PropertyName = "Scaling")]
        public double Scaling { get; set; }

        [JsonProperty(PropertyName = "DecimalPlaces")]
        public int DecimalPlaces { get; set; }

        [JsonProperty(PropertyName = "RowBorder")]
        public string RowBorder { get; set; }

        [JsonProperty(PropertyName = "CellBorder")]
        public string CellBorder { get; set; }
    }
}