﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR;

namespace Wells.Carina.Web.API.Hubs
{
    public abstract class CarinaHubBase : Hub
    {
        protected static ConnectionMapping<string> connections = new ConnectionMapping<string>();

        protected CarinaHubBase()
        { }

        public override Task OnConnected()
        {
            string gridRunTimeId = Context.QueryString["gridRuntimeId"];

            connections.Add(gridRunTimeId, Context.ConnectionId);

            return base.OnConnected();
        }

        public override Task OnDisconnected(bool stopCalled)
        {
            string gridRunTimeId = Context.QueryString["gridRuntimeId"];

            connections.Remove(gridRunTimeId, Context.ConnectionId);

            return base.OnDisconnected(stopCalled);
        }

        public override Task OnReconnected()
        {
            string gridRunTimeId = Context.QueryString["gridRuntimeId"];

            if (!connections.GetConnections(gridRunTimeId).Contains(Context.ConnectionId))
            {
                connections.Add(gridRunTimeId, Context.ConnectionId);
            }

            return base.OnReconnected();
        }
    }
}
